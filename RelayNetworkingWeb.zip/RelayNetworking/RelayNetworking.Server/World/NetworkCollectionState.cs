﻿using RelayNetworking.Common.Data;

namespace RelayNetworking.Server.World;

internal sealed class NetworkCollectionState
{
    public NetworkCollectionType CollectionType;
    public NetworkVariableAuthority Authority;
    public NetworkVariableType KeyType;
    public NetworkVariableType ValueType;

    public readonly List<object> List = new();
    public readonly Dictionary<object, object> Dictionary = new();
    public readonly HashSet<object> Set = new();
}
