﻿using LiteNetLib;
using RelayNetworking.Common.Rpc;

namespace RelayNetworking.Server.World;

internal struct RpcMethodState
{
    public RpcCaller Caller;

    public DeliveryMethod Delivery;
}