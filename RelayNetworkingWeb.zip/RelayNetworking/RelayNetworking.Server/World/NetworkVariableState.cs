﻿using RelayNetworking.Common.Data;

namespace RelayNetworking.Server.World;

internal sealed class NetworkVariableState
{
    public NetworkVariableType Type;

    public NetworkVariableAuthority Authority;
}