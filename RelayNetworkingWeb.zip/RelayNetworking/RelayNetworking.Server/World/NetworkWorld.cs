﻿using System.Collections.Generic;

namespace RelayNetworking.Server.World;

internal sealed class NetworkWorld
{
    private readonly Dictionary<uint, NetworkObjectState> _objects = new();

    public bool Add(NetworkObjectState obj)
    {
        return _objects.TryAdd(obj.NetworkId, obj);
    }

    public bool Remove(uint networkId)
    {
        return _objects.Remove(networkId);
    }

    public bool TryGet(uint networkId, out NetworkObjectState obj)
    {
        bool success = _objects.TryGetValue(networkId, out obj);
        return success;
    }

    public IEnumerable<NetworkObjectState> Objects => _objects.Values;
}