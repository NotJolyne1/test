﻿using RelayNetworking.Common.Data;
using RelayNetworking.Common.Rooms;
using RelayNetworking.Server.World;
using System.Numerics;

namespace RelayNetworking.Server.World;

internal sealed class NetworkObjectState
{
    internal Room? Room;
    public string AppId = "";
    public List<BufferedRpc> BufferedRpcs { get; } = new();

    public uint NetworkId;

    public ushort PrefabId;

    public int OwnerPlayerId;

    public bool LeaderCanControl;

    public Vector3 Position;

    public Quaternion Rotation;

    public Vector3 Velocity;

    public Vector3 AngularVelocity;

    internal bool KeepAfterOwnerLeaves = false;
    internal bool IsPlayer;


    public readonly Dictionary<uint, NetworkVariableState> Variables = new();
    public readonly HashSet<ushort> RegisteredVariableBehaviours = new();
    public readonly Dictionary<uint, object> Values = new();

    public readonly Dictionary<uint, NetworkCollectionState> Collections = new();
    public readonly HashSet<ushort> RegisteredCollectionBehaviours = new();

    public bool RpcsRegistered;
    public readonly Dictionary<uint, RpcMethodState> RpcMethods = new();

    public bool InterestBased;
    public readonly HashSet<int> InterestedPlayerIds = new();

    public byte ChildTransformCount;
    public Vector3[] ChildPositions = Array.Empty<Vector3>();
    public Quaternion[] ChildRotations = Array.Empty<Quaternion>();
    public bool[] ChildTransformReceived = Array.Empty<bool>();
}