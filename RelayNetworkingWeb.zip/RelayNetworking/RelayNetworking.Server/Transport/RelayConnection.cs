﻿using LiteNetLib;
using RelayNetworking.Common;
using RelayNetworking.Common.Rooms;
using RelayNetworking.Server.Security;

internal sealed class RelayConnection
{
    internal bool ReclamationDisconnect;
    public ConnectionState ConnectionState { get; internal set; } = ConnectionState.Connected;
    public ClientState State = ClientState.Connected;
    public Room? Room { get; internal set; }
    public RelayApplication? Application { get; internal set; }
    public DateTime ConnectedAt { get; } = DateTime.UtcNow;
    public DateTime LastPacketTime { get; set; } = DateTime.UtcNow;
    internal long LastTimeSyncTicks;
    internal string ReclamationToken = string.Empty;
    internal AuthenticationType AuthenticationType;
    internal bool PersistentAuthentication;
    internal bool CleanupCompleted;
    internal bool SceneReady = true;
    internal byte PlayerChildTransformCount;
    internal ushort ProtocolVersion = NetworkProtocol.LegacyVersion;
    public RelayConnection(NetPeer peer, RelayServerOptions options)
    {
        Peer = peer;

        PacketRate = new RateWindow(options.MaxPacketsPerSecond, TimeSpan.FromSeconds(1));
        ByteRate = new RateWindow(options.MaxBytesPerSecond, TimeSpan.FromSeconds(1));
        CommandRate = new RateWindow(options.MaxCommandsPerSecond, TimeSpan.FromSeconds(1));
        RoomCreateRate = new RateWindow(options.MaxRoomCreationsPerMinute, TimeSpan.FromMinutes(1));
        JoinRate = new RateWindow(options.MaxJoinsPerMinute, TimeSpan.FromMinutes(1));
        PropertyRate = new RateWindow(options.MaxPropertyUpdatesPerSecond, TimeSpan.FromSeconds(1));
        RpcRate = new RateWindow(options.MaxRpcCallsPerSecond, TimeSpan.FromSeconds(1));
        CollectionRate = new RateWindow(options.MaxCollectionUpdatesPerSecond, TimeSpan.FromSeconds(1));
    }

    internal RateWindow PacketRate { get; }
    internal RateWindow ByteRate { get; }
    internal RateWindow CommandRate { get; }
    internal RateWindow RoomCreateRate { get; }
    internal RateWindow JoinRate { get; }
    internal RateWindow PropertyRate { get; }
    internal RateWindow RpcRate { get; }
    internal RateWindow CollectionRate { get; }

    public int ViolationCount { get; internal set; }
    public int AuthAttempts { get; internal set; }

    public NetPeer Peer { get; }

    public bool Connected => Peer.ConnectionState == ConnectionState.Connected;

    public int Ping => Peer.Ping;

    public bool Authenticated { get; internal set; }

    public string AppId { get; internal set; } = string.Empty;

    public RelayPlayer? Player { get; internal set; }


    public enum ClientState
    {
        Connected,
        Handshaking,
        Authenticated,
        Ready,
        Disconnecting
    }
}