﻿using LiteNetLib;
using RelayNetworking.Client.Transport;
using RelayNetworking.Common;
using RelayNetworking.Common.Protocol;
using RelayNetworking.Common.Protocol.Networking;
using RelayNetworking.Common.Rooms;
using RelayNetworking.Common.Serialization;
using RelayNetworking.Server.Applications;
using RelayNetworking.Server.Authentication;
using RelayNetworking.Server.Protocol.Events;
using RelayNetworking.Server.Protocol.Handlers;
using RelayNetworking.Server.Ownership;
using RelayNetworking.Server.Rooms;
using RelayNetworking.Server.Security;
using RelayNetworking.Server.Time;
using RelayNetworking.Server.World;

namespace RelayNetworking.Server.Transport;

public sealed class RelayServer
{
    private readonly RelayListener _listener;
    private readonly NetManager _server;
    private readonly RelayServerOptions _options;
    private readonly Dictionary<NetPeer, RelayConnection> _connections = new();
    private readonly NetworkCommandHandler _commandHandler = new();
    private readonly Dictionary<AuthenticationType, IAuthenticationProvider> _authenticationProviders = new();
    private readonly Dictionary<string, int> _connectionsPerIp = new();
    private int _nextPlayerId = 1;

    internal IReadOnlyDictionary<NetPeer, RelayConnection> Connections => _connections;
    public IReadOnlyDictionary<AuthenticationType, IAuthenticationProvider> AuthenticationProviders => _authenticationProviders;
    internal RelayServerOptions Options => _options;

    internal RoomManager Rooms { get; }
    internal EventManager Events { get; }
    internal OwnershipReclamationManager OwnershipReclamation { get; }
    internal ApplicationManager Applications { get; } = new();
    internal AbuseProtectionManager Abuse { get; }
    private uint _nextNetworkId = 1;
    internal NetworkWorld World { get; }
    internal ushort PlayerPrefabId { get; set; }

    public ServerClock Clock { get; }

    public event Action<ulong>? OnTick;

    public RelayServer(RelayServerOptions options)
    {
        _options = options;

        Rooms = new RoomManager(options);
        Events = new EventManager(this);
        OwnershipReclamation = new OwnershipReclamationManager(options.OwnershipReclamationWindow, options.MaxConnections);
        Abuse = new AbuseProtectionManager(options, Applications);
        World = new NetworkWorld();
        Clock = new ServerClock(options.TickRate);

        _listener = new RelayListener();
        _server = new NetManager(_listener);

        _listener.ConnectionRequestEvent += request =>
        {
            string address = request.RemoteEndPoint.Address.ToString();

            if (Abuse.IsCoolingDown(address))
            {
                request.Reject();
                return;
            }

            if (!Abuse.TryConsumeConnectionAttempt(address))
            {
                Abuse.RegisterViolation(address, "connection rate exceeded");
                request.Reject();
                return;
            }

            if (_connections.Count >= _options.MaxConnections)
            {
                request.Reject();
                return;
            }

            if (_connectionsPerIp.GetValueOrDefault(address) >= _options.MaxConnectionsPerIp)
            {
                request.Reject();
                return;
            }

            request.AcceptIfKey(_options.ConnectionKey);
        };

        _listener.PeerConnectedEvent += peer =>
        {
            string address = peer.Address.ToString();

            int count = _connectionsPerIp.GetValueOrDefault(address);

            if (count >= _options.MaxConnectionsPerIp)
            {
                Console.WriteLine($"[Security] Too many connections from {address}, dropping");

                peer.Disconnect();

                return;
            }

            _connectionsPerIp[address] = count + 1;

            RelayConnection connection = new(peer, _options);

            _connections.Add(peer, connection);

            connection.State = RelayConnection.ClientState.Connected;

            Console.WriteLine($"[Server] Client connected ({address})");
        };

        _listener.PeerDisconnectedEvent += (peer, info) =>
        {
            if (_connections.TryGetValue(peer, out RelayConnection? connection))
            {
                connection.State = RelayConnection.ClientState.Disconnecting;

                if (info.Reason == DisconnectReason.Timeout)
                    SuspendOrDisconnect(connection, "connection timeout");
                else
                    CleanupConnection(connection, false);

                RemoveConnectionTracking(peer);
            }

            Console.WriteLine($"[Server] Client disconnected ({info.Reason})");
        };

        _listener.NetworkReceiveEvent += (peer, reader, deliveryMethod, _) =>
        {
            try
            {
                if (!_connections.TryGetValue(peer, out RelayConnection? connection))
                    return;
                connection.LastPacketTime = DateTime.UtcNow;

                int packetSize = reader.AvailableBytes;

                if (packetSize <= 0 || packetSize > _options.MaxPacketSize)
                {
                    Disconnect(connection, $"oversized packet with {packetSize} bytes");
                    return;
                }

                NetworkCommandReader commandReader = new(reader);

                CommandCode code = (CommandCode)commandReader.GetUShort();

                if (code != CommandCode.CmdTransform)
                {
                    if (!connection.PacketRate.TryConsume())
                    {
                        RegisterViolation(connection, "packet rate exceeded");
                        return;
                    }
                }

                if (!connection.ByteRate.TryConsume(packetSize))
                {
                    RegisterViolation(connection, "byte rate exceeded");
                    return;
                }

                switch (code)
                {
                    case CommandCode.CmdTransform:
                        break;

                    default:
                        if (!connection.CommandRate.TryConsume())
                        {
                            RegisterViolation(connection, $"command rate exceeded ({code})");
                            return;
                        }
                        break;
                }

                HandleSafely(connection, code, commandReader);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[Security] Packet processing failed for {peer.Address}: {ex.Message}");

                peer.Disconnect();
            }
            finally
            {
                reader.Recycle();
            }
        };

        RegisterAuthenticationProvider(
            AuthenticationType.None,
            new AnonymousAuthenticationProvider(options));
    }

    private async Task HandleSafely(RelayConnection connection, CommandCode code, NetworkCommandReader reader)
    {
        try
        {
            await _commandHandler.Handle(this, connection, code, reader);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[Security] Command handling failed for {connection.Peer.Address}: {ex.Message}");

            Disconnect(connection, "command handler failure");
        }
    }

    internal void RegisterViolation(RelayConnection connection, string reason, bool disconnect = false)
    {
        connection.ViolationCount++;

        Console.WriteLine($"[Security] Violation ({connection.ViolationCount}/{_options.ViolationsBeforeDisconnect}) from {connection.Peer.Address}: {reason}");

        if (connection.ViolationCount >= _options.ViolationsBeforeDisconnect || disconnect)
        {
            Disconnect(connection, "too many violations");
        }
    }

    internal void Disconnect(RelayConnection connection, string reason)
    {
        Console.WriteLine($"[Security] Disconnecting {connection.Peer.Address}: {reason}");

        CleanupConnection(connection, true);

        if (connection.Peer.ConnectionState == ConnectionState.Connected)
            connection.Peer.Disconnect();
    }

    private void SuspendOrDisconnect(RelayConnection connection, string reason)
    {
        if (OwnershipReclamation.Suspend(connection, DateTime.UtcNow))
        {
            Console.WriteLine($"[Server] Suspending {connection.Peer.Address}: {reason}");

            RemoveConnectionTracking(connection.Peer);

            if (connection.Peer.ConnectionState == ConnectionState.Connected)
                connection.Peer.Disconnect();

            return;
        }

        Disconnect(connection, reason);
    }

    private void CleanupConnection(RelayConnection connection, bool notifyClient)
    {
        if (connection.CleanupCompleted)
            return;

        connection.CleanupCompleted = true;
        OwnershipReclamation.Remove(connection);

        if (connection.Room == null || connection.Player == null)
            return;

        Room room = connection.Room;
        int playerId = connection.Player.PlayerId;

        DestroyOwnedObjects(connection);

        if (!Rooms.LeaveRoom(connection, out RelayPlayer? newLeader))
            return;

        foreach (RelayPlayer player in room.ActivePlayers)
        {
            RelayConnection? other = GetConnection(room, player);

            if (other == null)
                continue;

            Events.PlayerLeft(other, playerId);
        }

        if (newLeader != null)
        {
            foreach (RelayPlayer player in room.ActivePlayers)
            {
                RelayConnection? other = GetConnection(room, player);

                if (other == null)
                    continue;

                Events.LeaderChanged(other, newLeader);
            }
        }

        if (notifyClient && connection.Peer.ConnectionState == ConnectionState.Connected)
            Events.RoomLeft(connection);
    }

    private void RemoveConnectionTracking(NetPeer peer)
    {
        if (!_connections.Remove(peer))
            return;

        string address = peer.Address.ToString();

        if (!_connectionsPerIp.TryGetValue(address, out int count))
            return;

        if (count <= 1)
            _connectionsPerIp.Remove(address);
        else
            _connectionsPerIp[address] = count - 1;
    }

    public void Start()
    {
        _server.Start(_options.Port);

        Console.WriteLine($"[Server] Listening on {_options.Port}");
    }

    public void Stop()
    {
        _server.Stop();

        Console.WriteLine("[Server] Server stopped");
    }

    public void Poll()
    {
        _server.PollEvents();

        Clock.Advance(tick => OnTick?.Invoke(tick));

        DateTime now = DateTime.UtcNow;

        Abuse.Cleanup(now);

        foreach (RelayConnection connection in OwnershipReclamation.CollectExpired(now))
            CleanupConnection(connection, false);

        foreach (RelayConnection connection in _connections.Values.ToArray())
        {
            if (now - connection.LastPacketTime < _options.IdleTimeout)
                continue;

            SuspendOrDisconnect(connection, "idle timeout");
        }

        foreach (RelayConnection connection in _connections.Values.ToArray())
        {
            if (connection.Authenticated)
                continue;

            if (now - connection.ConnectedAt < _options.AuthenticationTimeout)
                continue;

            Console.WriteLine($"[Security] Authentication timeout {connection.Peer.Address}");

            connection.Peer.Disconnect();
        }
    }

    public void Send(NetPeer peer, INetworkCommand command, DeliveryMethod method = DeliveryMethod.ReliableOrdered)
    {
        peer.Send(NetworkCommandSerializer.Serialize(command), method);
    }

    public void Send(NetPeer peer, NetworkCommandWriter writer, DeliveryMethod method = DeliveryMethod.ReliableOrdered)
    {
        peer.Send(writer.Writer, method);
    }

    internal int GetNextPlayerId()
    {
        return _nextPlayerId++;
    }

    internal RelayConnection? GetConnection(Room room, RelayPlayer player)
    {
        foreach (RelayConnection connection in _connections.Values)
        {
            if (connection.Room == room && connection.Player == player)
                return connection;
        }

        return null;
    }

    public void RegisterAuthenticationProvider(AuthenticationType type, IAuthenticationProvider provider)
    {
        if (provider == null)
            throw new ArgumentNullException(nameof(provider));

        _authenticationProviders[type] = provider;
    }

    internal uint AllocateNetworkId()
    {
        return _nextNetworkId++;
    }

    internal void DestroyOwnedObjects(RelayConnection connection)
    {
        if (connection.Room == null || connection.Player == null)
            return;

        int leavingPlayerId = connection.Player.PlayerId;

        foreach (NetworkObjectState obj in World.Objects.ToList())
        {
            if (obj.OwnerPlayerId != connection.Player.PlayerId)
                continue;

            if (obj.Room != connection.Room || !string.Equals(obj.AppId, connection.AppId, StringComparison.OrdinalIgnoreCase))
                continue;

            if (obj.KeepAfterOwnerLeaves)
                continue;

            World.Remove(obj.NetworkId);

            foreach (RelayPlayer player in connection.Room.ActivePlayers)
            {
                if (obj.InterestBased && !obj.InterestedPlayerIds.Contains(player.PlayerId))
                    continue;

                RelayConnection? target = GetConnection(connection.Room, player);

                if (target == null)
                    continue;

                Events.ObjectDestroyed(target, obj.NetworkId);
            }
        }

        foreach (NetworkObjectState obj in World.Objects)
        {
            if (obj.Room != connection.Room)
                continue;

            obj.InterestedPlayerIds.Remove(leavingPlayerId);
        }

        connection.Player.PlayerObjectId = 0;
    }
}