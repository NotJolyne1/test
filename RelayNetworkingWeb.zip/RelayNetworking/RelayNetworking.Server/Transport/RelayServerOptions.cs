﻿public sealed class RelayServerOptions
{
    public int Port { get; set; } = 7777;
    public string ConnectionKey { get; set; } = "RelayNetworking";

    public TimeSpan AuthenticationTimeout { get; set; } = TimeSpan.FromSeconds(10);
    public TimeSpan IdleTimeout { get; set; } = TimeSpan.FromSeconds(100);

    public int MaxConnections { get; set; } = 4000;
    public int MaxConnectionsPerIp { get; set; } = 20;

    public int MaxPacketSize { get; set; } = 4096;

    public int MaxPacketsPerSecond { get; set; } = 60;
    public int MaxBytesPerSecond { get; set; } = 65536;
    public int MaxCommandsPerSecond { get; set; } = 40;

    public int MaxRoomCreationsPerMinute { get; set; } = 10;
    public int MaxJoinsPerMinute { get; set; } = 20;
    public int MaxPropertyUpdatesPerSecond { get; set; } = 20;

    public int MaxPlayerPropertyBytes { get; set; } = 4096;
    public int MaxRoomPropertyBytes { get; set; } = 8192;

    public int MaxAuthAttempts { get; set; } = 5;

    public int MaxUsernameLength { get; set; } = 32;
    public int MaxRoomNameLength { get; set; } = 64;
    public int MaxAppIdLength { get; set; } = 64;
    public int MaxAuthDataLength { get; set; } = 2048;

    public int MaxPlayersPerRoom { get; set; } = 10;

    public int MaxEventPayloadSize { get; set; } = 4096;
    public int MaxEventTargets { get; set; } = 32;
    public byte MaxEventId { get; set; } = byte.MaxValue;

    public int MaxRoomsPerApplication { get; set; } = 20000;

    public int ViolationsBeforeDisconnect { get; set; } = 8;

    public int MaxRpcCallsPerSecond { get; set; } = 30;
    public int MaxRpcParameters { get; set; } = 16;

    public int MaxCollectionUpdatesPerSecond { get; set; } = 30;
    public int MaxNetworkCollectionsPerBehaviour { get; set; } = 32;
    public int MaxNetworkCollectionItems { get; set; } = 128;

    public int TickRate { get; set; } = 60;

    public TimeSpan OwnershipReclamationWindow { get; set; } = TimeSpan.FromSeconds(20);

    public int MaxConnectionAttemptsPerIpPerMinute { get; set; } = 30;
    public int MaxAuthenticationAttemptsPerIpPerMinute { get; set; } = 20;
    public int MaxFailedAuthenticationAttemptsPerIpPerMinute { get; set; } = 8;

    public int MaxRoomCreationsPerIpPerMinute { get; set; } = 5;
    public int MaxRoomCreationsPerAppPerMinute { get; set; } = 100;
    public int MaxRoomCreationsPerIpPerAppPerMinute { get; set; } = 5;

    public int MaxRoomJoinsPerIpPerMinute { get; set; } = 30;
    public int MaxRoomJoinsPerIpPerAppPerMinute { get; set; } = 20;

    public int AbuseViolationsBeforeCooldown { get; set; } = 10;
    public TimeSpan AbuseCooldown { get; set; } = TimeSpan.FromMinutes(5);

    public TimeSpan AbuseStateCleanupInterval { get; set; } = TimeSpan.FromMinutes(10);
    public TimeSpan AbuseStateMaxIdle { get; set; } = TimeSpan.FromMinutes(30);
}