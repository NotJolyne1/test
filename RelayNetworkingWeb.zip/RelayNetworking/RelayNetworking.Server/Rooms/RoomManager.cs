﻿using RelayNetworking.Common;
using RelayNetworking.Common.Callbacks;
using RelayNetworking.Common.Collections;
using RelayNetworking.Common.Results;
using RelayNetworking.Common.Rooms;

namespace RelayNetworking.Server.Rooms;

internal sealed class RoomManager
{
    private readonly Dictionary<string, Dictionary<string, Room>> _rooms = new(StringComparer.OrdinalIgnoreCase);
    private readonly RelayServerOptions _options;

    public RoomManager(RelayServerOptions options)
    {
        _options = options;
    }

    public IReadOnlyCollection<Room> Rooms => _rooms.Values.SelectMany(x => x.Values).ToList();

    public bool TryGet(RelayConnection connection, string roomName, out Room room)
    {
        room = null!;

        if (!_rooms.TryGetValue(connection.AppId, out Dictionary<string, Room>? rooms))
            return false;

        return rooms.TryGetValue(roomName, out room!);
    }

    public bool AddRoom(RelayConnection connection, Room room)
    {
        if (!_rooms.TryGetValue(connection.AppId, out Dictionary<string, Room>? rooms))
        {
            rooms = new(StringComparer.OrdinalIgnoreCase);

            _rooms.Add(connection.AppId, rooms);
        }

        return rooms.TryAdd(room.Name, room);
    }

    public bool RemoveRoom(RelayConnection connection, string roomName)
    {
        if (!_rooms.TryGetValue(connection.AppId, out Dictionary<string, Room>? rooms))
            return false;

        bool removed = rooms.Remove(roomName);

        if (rooms.Count == 0)
            _rooms.Remove(connection.AppId);

        return removed;
    }

    public bool CreateRoom(RelayConnection connection, string roomName)
    {
        return CreateRoom(connection, roomName, new RoomOptions());
    }

    public bool CreateRoom(RelayConnection connection, string roomName, RoomOptions options)
    {
        if (connection.Player == null)
            return false;

        if (connection.Room != null)
            return false;

        options ??= new RoomOptions();

        if (!_rooms.TryGetValue(connection.AppId, out Dictionary<string, Room>? rooms))
        {
            rooms = new(StringComparer.OrdinalIgnoreCase);

            _rooms.Add(connection.AppId, rooms);
        }

        if (rooms.ContainsKey(roomName))
            return false;

        if (rooms.Count >= _options.MaxRoomsPerApplication)
            return false;

        int maxPlayers = Math.Clamp(options.MaxPlayers, 1, _options.MaxPlayersPerRoom);

        Room room = new()
        {
            Name = roomName
        };
        room.AppId = connection.AppId;
        room.MaxPlayers = maxPlayers;
        room.IsOpen = options.IsOpen;
        room.IsVisible = options.IsVisible;
        room.Properties[RoomProperties.CurrentSceneKey] = string.Empty;

        if (options.CustomProperties != null)
        {
            int roomBytes = RoomProperties.CurrentSceneKey.Length * sizeof(char);

            foreach (var property in options.CustomProperties)
            {
                if (property.Value == null)
                    continue;

                if (string.Equals(property.Key, RoomProperties.CurrentSceneKey, StringComparison.Ordinal))
                    continue;

                roomBytes += property.Key.Length * sizeof(char);

                if (property.Value is string value)
                    roomBytes += value.Length * sizeof(char);

                if (roomBytes > _options.MaxRoomPropertyBytes)
                    return false;

                room.Properties[property.Key] = property.Value;
            }
        }

        room.AddPlayer(connection.Player);

        connection.Room = room;

        rooms.Add(roomName, room);

        RelayCallbacks.OnRoomCreated(room);

        return true;
    }


    public JoinRoomResult JoinRoom(RelayConnection connection, string roomName)
    {
        if (connection.Player == null)
            return JoinRoomResult.JoinDenied;

        if (connection.Room != null)
            return JoinRoomResult.AlreadyInRoom;

        if (!_rooms.TryGetValue(connection.AppId, out Dictionary<string, Room>? rooms))
            return JoinRoomResult.RoomNotFound;

        if (!rooms.TryGetValue(roomName, out Room? room))
            return JoinRoomResult.RoomNotFound;

        if (room.AppId != connection.AppId)
        {
            Console.WriteLine($"[Security] App isolation violation from {connection.Peer.Address}");
            return JoinRoomResult.RoomNotFound;
        }

        if (!room.IsOpen)
            return JoinRoomResult.RoomClosed;

        if (room.ActivePlayers.Count >= room.MaxPlayers)
            return JoinRoomResult.RoomFull;

        if (!room.AddPlayer(connection.Player))
            return JoinRoomResult.JoinDenied;

        connection.Room = room;

        return JoinRoomResult.Success;
    }

    public JoinRoomResult JoinRandomRoom(RelayConnection connection, out Room? joinedRoom)
    {
        return JoinRandomRoom(connection, null, out joinedRoom);
    }

    public JoinRoomResult JoinRandomRoom(RelayConnection connection, IReadOnlyDictionary<string, object?>? filter, out Room? joinedRoom)
    {
        joinedRoom = null;

        if (connection.Player == null)
            return JoinRoomResult.JoinDenied;

        if (connection.Room != null)
            return JoinRoomResult.AlreadyInRoom;

        if (!_rooms.TryGetValue(connection.AppId, out Dictionary<string, Room>? rooms))
            return JoinRoomResult.RoomNotFound;

        Room? best = null;
        int bestCount = -1;
        int ties = 0;

        foreach (Room room in rooms.Values)
        {
            if (room.AppId != connection.AppId)
                continue;

            if (!room.IsVisible || !room.IsOpen)
                continue;

            if (room.ActivePlayers.Count >= room.MaxPlayers)
                continue;

            if (!MatchesFilter(room, filter))
                continue;

            int count = room.ActivePlayers.Count;

            if (count > bestCount)
            {
                bestCount = count;
                best = room;
                ties = 1;
            }
            else if (count == bestCount)
            {
                ties++;

                if (Random.Shared.Next(ties) == 0)
                    best = room;
            }
        }

        if (best == null)
            return JoinRoomResult.RoomNotFound;

        JoinRoomResult result = JoinRoom(connection, best.Name);

        if (result == JoinRoomResult.Success)
            joinedRoom = connection.Room;

        return result;
    }

    private static bool MatchesFilter(Room room, IReadOnlyDictionary<string, object?>? filter)
    {
        if (filter == null || filter.Count == 0)
            return true;

        foreach (var pair in filter)
        {
            if (!room.Properties.Contains(pair.Key))
                return false;

            object? actual = room.Properties[pair.Key];

            if (!PropertyValuesEqual(actual, pair.Value))
                return false;
        }

        return true;
    }

    private static bool PropertyValuesEqual(object? a, object? b)
    {
        if (a == null || b == null)
            return a == null && b == null;

        return a.Equals(b);
    }

    public bool LeaveRoom(RelayConnection connection, out RelayPlayer? newLeader)
    {
        newLeader = null;

        if (connection.Room != null && connection.Room.AppId != connection.AppId)
        {
            Console.WriteLine($"[Security] Room ownership violation");
            connection.Peer.Disconnect();
            return false;
        }

        if (connection.Player == null)
            return false;

        if (connection.Room == null)
            return false;

        Room room = connection.Room;

        bool leaderLeft = room.Leader == connection.Player;

        if (!room.RemovePlayer(connection.Player))
            return false;

        connection.Room = null;

        if (room.ActivePlayers.Count == 0)
        {
            if (_rooms.TryGetValue(connection.AppId, out Dictionary<string, Room>? rooms))
            {
                rooms.Remove(room.Name);

                if (rooms.Count == 0)
                    _rooms.Remove(connection.AppId);
            }
            RelayCallbacks.OnRoomClosed(room);
        }
        else if (leaderLeft)
        {
            newLeader = room.Leader;
        }

        return true;
    }
}