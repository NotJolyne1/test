﻿using System.Security.Cryptography;
using System.Text;

namespace RelayNetworking.Server.Ownership;

internal sealed class OwnershipReclamationManager
{
    private readonly Dictionary<string, OwnershipReclamationSession> _sessions = new(StringComparer.Ordinal);
    private readonly TimeSpan _window;
    private readonly int _maxPending;

    public OwnershipReclamationManager(TimeSpan window, int maxPending)
    {
        _window = window < TimeSpan.Zero ? TimeSpan.Zero : window;
        _maxPending = Math.Max(0, maxPending);
    }

    public string IssueToken()
    {
        byte[] bytes = RandomNumberGenerator.GetBytes(32);
        return Convert.ToBase64String(bytes);
    }

    public bool Suspend(RelayConnection connection, DateTime now)
    {
        if (_window <= TimeSpan.Zero || _maxPending == 0)
            return false;

        if (_sessions.Count >= _maxPending)
            return false;

        if (connection.CleanupCompleted || !connection.Authenticated || connection.Player == null || connection.Room == null)
            return false;

        if (string.IsNullOrEmpty(connection.ReclamationToken))
            return false;

        if (!string.Equals(connection.Room.AppId, connection.AppId, StringComparison.OrdinalIgnoreCase))
            return false;

        if (!connection.Room.ActivePlayers.Contains(connection.Player))
            return false;

        string key = HashToken(connection.ReclamationToken);

        _sessions[key] = new OwnershipReclamationSession
        {
            Connection = connection,
            AppId = connection.AppId,
            AuthenticationType = connection.AuthenticationType,
            PersistentAuthentication = connection.PersistentAuthentication,
            UserId = connection.Player.UserId,
            ExpiresAt = now + _window
        };

        return true;
    }

    public bool TryReclaim(
        RelayConnection connection,
        string token,
        AuthenticationType authenticationType,
        string authenticatedUserId,
        bool persistentAuthentication,
        DateTime now)
    {
        if (string.IsNullOrEmpty(token) || token.Length > 128)
            return false;

        string key = HashToken(token);

        if (!_sessions.TryGetValue(key, out OwnershipReclamationSession? session))
            return false;

        if (session.ExpiresAt <= now)
            return false;

        if (!string.Equals(session.AppId, connection.AppId, StringComparison.OrdinalIgnoreCase))
            return false;

        if (session.AuthenticationType != authenticationType)
            return false;

        if (session.PersistentAuthentication != persistentAuthentication)
            return false;

        if (persistentAuthentication && !string.Equals(session.UserId, authenticatedUserId, StringComparison.Ordinal))
            return false;

        RelayConnection suspended = session.Connection;

        if (suspended.CleanupCompleted || suspended.Player == null || suspended.Room == null)
            return false;

        if (!string.Equals(suspended.Room.AppId, connection.AppId, StringComparison.OrdinalIgnoreCase))
            return false;

        if (!suspended.Room.ActivePlayers.Contains(suspended.Player))
            return false;

        _sessions.Remove(key);

        connection.Player = suspended.Player;
        connection.Room = suspended.Room;
        connection.AuthenticationType = authenticationType;
        connection.PersistentAuthentication = persistentAuthentication;
        connection.ReclamationToken = IssueToken();

        suspended.Player = null;
        suspended.Room = null;
        suspended.ReclamationToken = string.Empty;
        suspended.CleanupCompleted = true;

        return true;
    }

    public IReadOnlyList<RelayConnection> CollectExpired(DateTime now)
    {
        if (_sessions.Count == 0)
            return Array.Empty<RelayConnection>();

        List<string>? expiredKeys = null;
        List<RelayConnection>? expiredConnections = null;

        foreach (KeyValuePair<string, OwnershipReclamationSession> pair in _sessions)
        {
            if (pair.Value.ExpiresAt > now)
                continue;

            expiredKeys ??= new List<string>();
            expiredConnections ??= new List<RelayConnection>();
            expiredKeys.Add(pair.Key);
            expiredConnections.Add(pair.Value.Connection);
        }

        if (expiredKeys == null || expiredConnections == null)
            return Array.Empty<RelayConnection>();

        foreach (string key in expiredKeys)
            _sessions.Remove(key);

        return expiredConnections;
    }

    public void Remove(RelayConnection connection)
    {
        if (_sessions.Count == 0)
            return;

        string? found = null;

        foreach (KeyValuePair<string, OwnershipReclamationSession> pair in _sessions)
        {
            if (!ReferenceEquals(pair.Value.Connection, connection))
                continue;

            found = pair.Key;
            break;
        }

        if (found != null)
            _sessions.Remove(found);
    }

    private static string HashToken(string token)
    {
        byte[] hash = SHA256.HashData(Encoding.UTF8.GetBytes(token));
        return Convert.ToHexString(hash);
    }
}

internal sealed class OwnershipReclamationSession
{
    public RelayConnection Connection { get; init; } = null!;
    public string AppId { get; init; } = string.Empty;
    public AuthenticationType AuthenticationType { get; init; }
    public bool PersistentAuthentication { get; init; }
    public string UserId { get; init; } = string.Empty;
    public DateTime ExpiresAt { get; init; }
}