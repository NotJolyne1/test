﻿using LiteNetLib;
using RelayNetworking.Common;
using RelayNetworking.Common.Authentication;
using RelayNetworking.Common.Callbacks;
using RelayNetworking.Common.Collections;
using RelayNetworking.Common.Data;
using RelayNetworking.Common.Protocol;
using RelayNetworking.Common.Protocol.Networking;
using RelayNetworking.Common.Results;
using RelayNetworking.Common.Rooms;
using RelayNetworking.Common.Rpc;
using RelayNetworking.Common.Serialization;
using RelayNetworking.Server.Authentication;
using RelayNetworking.Server.Transport;
using RelayNetworking.Server.World;
using System.Numerics;
using static RelayConnection;

namespace RelayNetworking.Server.Protocol.Handlers;

internal sealed class NetworkCommandHandler
{
    private readonly Dictionary<string, object?> _custom = new();
    public IReadOnlyDictionary<string, object?> Custom => _custom;
    private const int MaxCustomProperties = 64;
    private const int MaxSceneNameLength = 128;

    public async Task Handle(RelayServer server, RelayConnection connection, CommandCode code, NetworkCommandReader reader)
    {
        if (connection.State != ClientState.Ready)
        {
            switch (code)
            {
                case CommandCode.CmdAuthenticate:
                case CommandCode.CmdPing:
                case CommandCode.CmdTimeSyncRequest:
                    break;

                default:
                    Console.WriteLine($"[Security] Ignored {code} from {connection.Peer.Id} ({connection.State})");
                    return;
            }
        }


        switch (code)
        {
            case CommandCode.CmdAuthenticate:
                {
                    if (connection.State == ClientState.Ready)
                    {
                        server.Disconnect(connection, "already authenticated");
                        break;
                    }

                    if (connection.AuthAttempts >= server.Options.MaxAuthAttempts)
                    {
                        server.Disconnect(connection, "too many auth attempts");
                        break;
                    }

                    connection.AuthAttempts++;

                    string authIp = connection.Peer.Address.ToString();

                    if (server.Abuse.IsCoolingDown(authIp))
                    {
                        server.Disconnect(connection, "ip cooling down");
                        break;
                    }

                    if (!server.Abuse.TryConsumeAuthAttempt(authIp))
                    {
                        server.Abuse.RegisterViolation(authIp, "authentication rate exceeded");
                        server.Disconnect(connection, "authentication rate exceeded");
                        break;
                    }

                    connection.State = ClientState.Handshaking;

                    string appId = reader.GetString();
                    AuthenticationType type = (AuthenticationType)reader.GetByte();
                    string username = reader.GetString();
                    byte[] data = reader.GetBytes();
                    string reclamationToken = reader.AvailableBytes > 0 ? reader.GetString() : string.Empty;
                    byte playerChildTransformCount = reader.AvailableBytes > 0 ? reader.GetByte() : (byte)0;
                    ushort protocolVersion = reader.AvailableBytes > 0
                        ? reader.GetUShort()
                        : NetworkProtocol.LegacyVersion;

                    if (playerChildTransformCount > 64)
                        playerChildTransformCount = 64;

                    connection.PlayerChildTransformCount = playerChildTransformCount;
                    connection.ProtocolVersion = protocolVersion;

                    if (string.IsNullOrWhiteSpace(appId) || appId.Length > server.Options.MaxAppIdLength)
                    {
                        server.Disconnect(connection, "invalid app id");
                        break;
                    }

                    if (username == null || username.Length == 0 || username.Length > server.Options.MaxUsernameLength)
                    {
                        server.Disconnect(connection, "invalid username");
                        break;
                    }


                    if (username.Length > server.Options.MaxUsernameLength)
                    {
                        server.Disconnect(connection, "username too long");
                        break;
                    }

                    if (data.Length > server.Options.MaxAuthDataLength)
                    {
                        server.Disconnect(connection, "auth payload too large");
                        break;
                    }

                    username = username.Trim();

                    connection.AppId = appId;

                    AuthenticationRequest request = new()
                    {
                        AppId = appId,
                        Type = type,
                        Username = username,
                        Data = data
                    };

                    if (!server.AuthenticationProviders.TryGetValue(type, out IAuthenticationProvider? provider))
                    {
                        server.Disconnect(connection, $"unsupported auth type {type}");
                        break;
                    }
                    AuthenticationResult result = await provider.AuthenticateAsync(request);

                    if (!result.Success)
                    {
                        server.Abuse.RecordFailedAuth(authIp);
                        server.Disconnect(connection, $"auth failed ({result.ErrorMessage})");
                        break;
                    }

                    string finalUsername = string.IsNullOrWhiteSpace(result.Username) ? request.Username : result.Username;

                    if (finalUsername.Length > server.Options.MaxUsernameLength)
                        finalUsername = finalUsername[..server.Options.MaxUsernameLength];

                    connection.AuthenticationType = type;
                    connection.PersistentAuthentication = provider.IsPersistent;

                    bool reclaimed = server.OwnershipReclamation.TryReclaim(
                        connection,
                        reclamationToken,
                        type,
                        result.UserId,
                        provider.IsPersistent,
                        DateTime.UtcNow);

                    if (reclaimed)
                    {
                        connection.Authenticated = true;
                        connection.State = ClientState.Ready;
                        connection.Player!.Username = finalUsername;

                        server.Events.Authenticated(connection);
                        SyncReclaimedSession(server, connection);
                        server.Events.OwnershipReclaimed(connection);

                        Console.WriteLine($"[Auth] Reclaimed {connection.Player.Username} {connection.Player.UserId}");
                        break;
                    }

                    connection.Authenticated = true;
                    connection.ReclamationToken = server.OwnershipReclamation.IssueToken();

                    RelayPlayer player = new()
                    {
                        PlayerId = server.GetNextPlayerId(),
                        UserId = result.UserId,
                        Username = finalUsername
                    };

                    connection.Player = player;
                    connection.State = ClientState.Ready;

                    server.Events.Authenticated(connection);

                    Console.WriteLine($"[Auth] {player.Username} {player.UserId}");

                    break;
                }
            case CommandCode.CmdCreateRoom:
                {
                    if (!connection.RoomCreateRate.TryConsume())
                    {
                        server.RegisterViolation(connection, "room creation rate exceeded");
                        break;
                    }

                    string createIp = connection.Peer.Address.ToString();

                    if (server.Abuse.IsCoolingDown(createIp))
                    {
                        server.Events.RoomCreationFailed(connection, "rate limited");
                        break;
                    }

                    if (!server.Abuse.TryConsumeRoomCreation(createIp, connection.AppId))
                    {
                        server.Abuse.RegisterViolation(createIp, $"room creation rate exceeded AppId {connection.AppId}");
                        server.Events.RoomCreationFailed(connection, "rate limited");
                        break;
                    }

                    string roomName = reader.GetString();

                    if (string.IsNullOrWhiteSpace(roomName) || roomName.Length > server.Options.MaxRoomNameLength)
                    {
                        server.RegisterViolation(connection, "invalid room name");
                        break;
                    }

                    int maxPlayers = reader.GetInt();
                    bool isOpen = reader.GetBool();
                    bool isVisible = reader.GetBool();

                    PropertyChanges customProperties = new();
                    PropertySerializer.ReadCustom(reader, customProperties);

                    RoomOptions options = new()
                    {
                        MaxPlayers = maxPlayers,
                        IsOpen = isOpen,
                        IsVisible = isVisible
                    };

                    foreach (var property in customProperties.Custom)
                    {
                        if (property.Value == null)
                            continue;

                        if (string.Equals(property.Key, RoomProperties.CurrentSceneKey, StringComparison.Ordinal))
                            continue;

                        options.CustomProperties[property.Key] = property.Value;
                    }

                    if (server.Rooms.CreateRoom(connection, roomName, options))
                    {
                        server.Events.RoomCreated(connection, connection.Room!);
                        Room? room = connection.Room;

                        if (room == null)
                            return;

                        foreach (RelayPlayer player in room.ActivePlayers)
                        {
                            server.Events.PlayerSync(connection, player);
                        }
                        PropertyChanges roomProperties = new();

                        foreach (var property in room.Properties)
                        {
                            roomProperties[property.Key] = property.Value;
                        }

                        server.Events.RoomProperties(connection, room, roomProperties);
                        SpawnPlayer(server, connection);
                        Console.WriteLine($"[Room] Created '{roomName}'");
                    }
                    else
                    {
                        Console.Error.WriteLine($"[Room] Failed to create '{roomName}'");
                    }
                    break;
                }

            case CommandCode.CmdJoinRoom:
                {
                    if (!connection.JoinRate.TryConsume())
                    {
                        server.RegisterViolation(connection, "join rate exceeded");
                        break;
                    }

                    string joinIp = connection.Peer.Address.ToString();

                    if (server.Abuse.IsCoolingDown(joinIp))
                    {
                        server.Events.RoomJoinFailed(connection, JoinRoomResult.JoinDenied);
                        break;
                    }

                    if (!server.Abuse.TryConsumeRoomJoin(joinIp, connection.AppId))
                    {
                        server.Abuse.RegisterViolation(joinIp, $"room join rate exceeded AppId {connection.AppId}");
                        server.Events.RoomJoinFailed(connection, JoinRoomResult.JoinDenied);
                        break;
                    }

                    string roomName = reader.GetString();

                    if (string.IsNullOrWhiteSpace(roomName) || roomName.Length > server.Options.MaxRoomNameLength)
                    {
                        server.RegisterViolation(connection, "invalid room name");
                        break;
                    }

                    JoinRoomResult result = server.Rooms.JoinRoom(connection, roomName);

                    if (result == JoinRoomResult.Success)
                    {
                        HandleSuccessfulRoomJoin(server, connection);

                        Console.WriteLine($"[Room] Joined '{roomName}'");
                    }
                    else
                    {
                        server.Events.RoomJoinFailed(connection, result);

                        Console.WriteLine($"[Room] Failed to join '{roomName}' ({result})");
                    }
                    break;
                }

            case CommandCode.CmdLeaveRoom:
                {
                    if (connection.Room == null)
                        break;

                    Room room = connection.Room;
                    int playerId = connection.Player!.PlayerId;

                    server.DestroyOwnedObjects(connection);

                    if (server.Rooms.LeaveRoom(connection, out RelayPlayer? newLeader))
                    {
                        server.Events.RoomLeft(connection);
                        foreach (RelayPlayer player in room.ActivePlayers)
                        {
                            RelayConnection? other = server.GetConnection(room, player);

                            if (other == null)
                                continue;

                            server.Events.PlayerLeft(other, playerId);
                        }

                        if (newLeader != null)
                        {
                            foreach (RelayPlayer player in room.ActivePlayers)
                            {
                                RelayConnection? other = server.GetConnection(room, player);

                                if (other == null)
                                    continue;

                                server.Events.LeaderChanged(other, newLeader);
                            }
                        }

                        Console.WriteLine("[Room] Left");
                    }

                    break;
                }

            case CommandCode.CmdJoinRandomRoom:
                {
                    if (!connection.JoinRate.TryConsume())
                    {
                        server.RegisterViolation(connection, "join rate exceeded");
                        break;
                    }

                    string joinRandomIp = connection.Peer.Address.ToString();

                    if (server.Abuse.IsCoolingDown(joinRandomIp))
                    {
                        server.Events.RoomJoinFailed(connection, JoinRoomResult.JoinDenied);
                        break;
                    }

                    if (!server.Abuse.TryConsumeRoomJoin(joinRandomIp, connection.AppId))
                    {
                        server.Abuse.RegisterViolation(joinRandomIp, $"room join rate exceeded AppId {connection.AppId}");
                        server.Events.RoomJoinFailed(connection, JoinRoomResult.JoinDenied);
                        break;
                    }

                    PropertyChanges filterChanges = new();
                    PropertySerializer.ReadCustom(reader, filterChanges);

                    IReadOnlyDictionary<string, object?>? filter =
                        filterChanges.Custom.Count > 0 ? filterChanges.Custom : null;

                    JoinRoomResult result = server.Rooms.JoinRandomRoom(connection, filter, out Room? joinedRoom);

                    if (result == JoinRoomResult.Success)
                    {
                        HandleSuccessfulRoomJoin(server, connection);

                        Console.WriteLine($"[Room] Join Random '{joinedRoom?.Name}'");
                    }
                    else
                    {
                        server.Events.RoomJoinFailed(connection, result);

                        Console.WriteLine($"[Room] Join Random failed ({result})");
                    }

                    break;
                }

            case CommandCode.CmdPing:
                {
                    long time = reader.GetLong();

                    server.Events.Ping(connection, time);
                    break;
                }

            case CommandCode.CmdTimeSyncRequest:
                {
                    ulong requestId = reader.GetULong();

                    server.Events.TimeSync(
                        connection,
                        requestId,
                        server.Clock.ServerTime,
                        server.Clock.CurrentTick,
                        server.Clock.TickRate);

                    break;
                }

            case CommandCode.CmdPlayerProperties:
                {
                    if (!connection.PropertyRate.TryConsume())
                    {
                        server.RegisterViolation(connection, "property update rate exceeded");
                        break;
                    }

                    if (connection.Room == null || connection.Player == null)
                    {
                        server.RegisterViolation(connection, "property update outside a room");
                        break;
                    }

                    int playerId = reader.GetInt();

                    RelayConnection? target = null;

                    foreach (RelayPlayer player in connection.Room.ActivePlayers)
                    {
                        if (player.PlayerId != playerId)
                            continue;

                        target = server.GetConnection(connection.Room, player);
                        break;
                    }

                    if (target == null)
                        break;

                    PropertyChanges changes = new();

                    PropertySerializer.ReadReserved(reader, changes);
                    PropertySerializer.ReadCustom(reader, changes);

                    bool changed = false;

                    // Reserved
                    foreach (var property in changes.Reserved)
                    {
                        if (target != connection)
                            continue;

                        switch (property.Key)
                        {
                            case ReservedPlayerProperty.Username:

                                if (property.Value is string username && username.Length <= server.Options.MaxUsernameLength)
                                {
                                    target.Player!.Username = username;
                                    changed = true;
                                }

                                break;
                        }
                    }

                    bool canEditCustom = target == connection || connection.Player.IsLeader;

                    if (canEditCustom)
                    {
                        foreach (var property in changes.Custom)
                        {
                            if (property.Value == null)
                                target.Player!.Properties.Custom.Remove(property.Key);
                            else
                                target.Player!.Properties.TrySetCustom(property.Key, property.Value);

                            changed = true;
                        }
                    }

                    if (target.Player!.Properties.GetEstimatedSize() > server.Options.MaxPlayerPropertyBytes)
                    {
                        server.RegisterViolation(connection, "player property limit exceeded");
                        break;
                    }

                    if (changed)
                    {
                        foreach (RelayPlayer player in target.Room!.ActivePlayers)
                        {
                            RelayConnection? other = server.GetConnection(target.Room!, player);

                            if (other == null)
                                continue;

                            server.Events.PlayerProperties(other, target.Player, changes);
                        }
                        RelayCallbacks.OnPlayerPropertiesChanged(target.Player);
                    }

                    break;
                }

            case CommandCode.CmdRoomProperties:
                {
                    if (connection.Player == null)
                        break;

                    if (connection.Room == null)
                        break;

                    if (!connection.Player.IsLeader)
                        break;

                    if (!connection.PropertyRate.TryConsume())
                    {
                        server.RegisterViolation(connection, "property update rate exceeded");
                        break;
                    }

                    PropertyChanges changes = new();

                    PropertySerializer.ReadReserved(reader, changes);
                    PropertySerializer.ReadCustom(reader, changes);

                    bool changed = false;

                    if (changes.Custom.Remove(RoomProperties.CurrentSceneKey))
                        server.RegisterViolation(connection, "attempted to modify reserved room property");

                    foreach (var property in changes.Custom)
                    {
                        if (property.Value == null)
                            connection.Room.Properties.Remove(property.Key);
                        else
                            connection.Room.Properties[property.Key] = property.Value;

                        changed = true;
                    }

                    int roomBytes = 0;

                    foreach (var property in connection.Room.Properties)
                    {
                        roomBytes += property.Key.Length * sizeof(char);

                        if (property.Value is string value)
                            roomBytes += value.Length * sizeof(char);
                    }

                    if (roomBytes > server.Options.MaxRoomPropertyBytes)
                    {
                        server.RegisterViolation(connection, "room property limit exceeded");
                        break;
                    }

                    if (!changed)
                        break;

                    foreach (RelayPlayer player in connection.Room.ActivePlayers)
                    {
                        RelayConnection? other = server.GetConnection(connection.Room, player);

                        if (other == null)
                            continue;

                        server.Events.RoomProperties(other, connection.Room, changes);
                    }

                    break;
                }

            case CommandCode.CmdEvent:
                {
                    if (connection.Room == null)
                    {
                        server.RegisterViolation(connection, "event outside room");
                        break;
                    }

                    Room room = connection.Room;

                    byte eventCode = reader.GetByte();
                    EventTarget target = (EventTarget)reader.GetByte();

                    byte targetCount = reader.GetByte();

                    if (targetCount > 32)
                    {
                        server.RegisterViolation(connection, "too many event targets");
                        break;
                    }

                    int[] targets = new int[targetCount];

                    for (int i = 0; i < targetCount; i++)
                        targets[i] = reader.GetInt();

                    byte[] payload = reader.GetBytes();

                    ulong sentTick = server.Clock.CurrentTick;

                    if (targetCount > 0)
                    {
                        HashSet<int> sent = new();

                        foreach (RelayPlayer player in room.ActivePlayers)
                        {
                            if (!targets.Contains(player.PlayerId))
                                continue;

                            if (!sent.Add(player.PlayerId))
                                continue;

                            RelayConnection? other = server.GetConnection(room, player);

                            if (other == null)
                                continue;

                            server.Events.EventReceived(
                                other,
                                connection.Player!.PlayerId,
                                eventCode,
                                payload,
                                sentTick);
                        }

                        break;
                    }
                    Console.WriteLine($"Relaying event: {eventCode}");
                    switch (target)
                    {
                        case EventTarget.All:
                            {
                                foreach (RelayPlayer player in room.ActivePlayers)
                                {
                                    RelayConnection? other = server.GetConnection(room, player);

                                    if (other == null)
                                        continue;

                                    server.Events.EventReceived(
                                        other,
                                        connection.Player!.PlayerId,
                                        eventCode,
                                        payload,
                                        sentTick);
                                }

                                break;
                            }

                        case EventTarget.Others:
                            {
                                foreach (RelayPlayer player in room.ActivePlayers)
                                {
                                    if (player == connection.Player)
                                        continue;

                                    RelayConnection? other = server.GetConnection(room, player);

                                    if (other == null)
                                        continue;

                                    server.Events.EventReceived(
                                        other,
                                        connection.Player!.PlayerId,
                                        eventCode,
                                        payload,
                                        sentTick);
                                }

                                break;
                            }

                        case EventTarget.Self:
                            {
                                server.Events.EventReceived(
                                    connection,
                                    connection.Player!.PlayerId,
                                    eventCode,
                                    payload,
                                    sentTick);

                                break;
                            }

                        case EventTarget.Leader:
                            {
                                RelayPlayer? leader = room.Leader;

                                if (leader != null)
                                {
                                    RelayConnection? other = server.GetConnection(room, leader);

                                    if (other != null)
                                    {
                                        server.Events.EventReceived(other, connection.Player!.PlayerId, eventCode, payload, sentTick);
                                    }
                                }

                                break;
                            }
                    }

                    break;
                }

            case CommandCode.CmdSpawn:
                {
                    if (connection.Player == null || connection.Room == null)
                        break;

                    ushort prefabId = reader.GetUShort();

                    float x = reader.GetFloat();
                    float y = reader.GetFloat();
                    float z = reader.GetFloat();

                    float rx = reader.GetFloat();
                    float ry = reader.GetFloat();
                    float rz = reader.GetFloat();
                    float rw = reader.GetFloat();

                    bool interestBased = reader.GetBool();

                    ushort interestedCount = reader.GetUShort();

                    if (interestedCount > server.Options.MaxPlayersPerRoom)
                    {
                        server.RegisterViolation(connection, "interested player count exceeds room maximum");
                        break;
                    }

                    HashSet<int> interested = new();

                    for (int i = 0; i < interestedCount; i++)
                    {
                        int playerId = reader.GetInt();

                        if (!interestBased)
                            continue;

                        RelayPlayer? candidate = connection.Room.ActivePlayers.FirstOrDefault(p => p.PlayerId == playerId);

                        if (candidate == null)
                            continue;

                        RelayConnection? candidateConnection = server.GetConnection(connection.Room, candidate);

                        if (candidateConnection == null || !string.Equals(candidateConnection.AppId, connection.AppId, StringComparison.OrdinalIgnoreCase))
                            continue;

                        interested.Add(playerId);
                    }

                    uint networkId = server.AllocateNetworkId();

                    byte childTransformCount = reader.GetByte();
                    uint spawnRequestId = reader.AvailableBytes >= 4 ? reader.GetUInt() : 0;

                    if (childTransformCount > 64)
                    {
                        server.RegisterViolation(connection, "child transform count exceeds maximum");

                        if (spawnRequestId != 0)
                            server.Events.SpawnFailed(connection, spawnRequestId);

                        break;
                    }

                    NetworkObjectState obj = new()
                    {
                        NetworkId = networkId,
                        PrefabId = prefabId,
                        OwnerPlayerId = connection.Player.PlayerId,
                        LeaderCanControl = false,
                        KeepAfterOwnerLeaves = false,
                        IsPlayer = false,
                        Room = connection.Room,
                        AppId = connection.AppId,
                        Position = new(x, y, z),
                        Rotation = new(rx, ry, rz, rw),
                        InterestBased = interestBased,
                        ChildTransformCount = childTransformCount
                    };

                    AllocateChildTransforms(obj);

                    if (interestBased)
                    {
                        foreach (int playerId in interested)
                            obj.InterestedPlayerIds.Add(playerId);

                        obj.InterestedPlayerIds.Add(connection.Player.PlayerId);
                    }

                    if (!server.World.Add(obj))
                    {
                        Console.WriteLine($"[Server] Failed to register object {obj.NetworkId}");

                        if (spawnRequestId != 0)
                            server.Events.SpawnFailed(connection, spawnRequestId);

                        return;
                    }

                    foreach (RelayPlayer player in connection.Room.ActivePlayers)
                    {
                        if (!IsObjectVisibleTo(obj, player.PlayerId))
                            continue;

                        RelayConnection? target = server.GetConnection(connection.Room, player);

                        if (target == null)
                            continue;

                        server.Events.ObjectSpawned(
                            target,
                            prefabId,
                            networkId,
                            connection.Player.PlayerId,
                            false,
                            x,
                            y,
                            z,
                            rx,
                            ry,
                            rz,
                            rw,
                            target == connection ? spawnRequestId : 0);
                    }

                    break;
                }

            case CommandCode.CmdDestroy:
                {
                    if (connection.Player == null)
                        return;

                    if (connection.Room == null)
                        return;

                    uint networkId = reader.GetUInt();
                    Console.WriteLine($"Destroy request {networkId}");
                    if (!server.World.TryGet(networkId, out NetworkObjectState obj))
                        return;

                    if (!ObjectBelongsToConnection(connection, obj))
                    {
                        server.RegisterViolation(connection, "network object outside room scope");
                        return;
                    }

                    bool canDestroy =
                        obj.OwnerPlayerId == connection.Player.PlayerId ||
                        (obj.LeaderCanControl && connection.Player.IsLeader);
                    if (!canDestroy)
                        return;

                    if (!server.World.Remove(networkId))
                    {
                        Console.WriteLine($"[Server] Failed to remove object {networkId}");
                        return;
                    }

                    foreach (RelayPlayer player in connection.Room.ActivePlayers)
                    {
                        if (!IsObjectVisibleTo(obj, player.PlayerId))
                            continue;

                        RelayConnection target =
                            server.GetConnection(connection.Room, player);

                        if (target == null)
                            continue;

                        server.Events.ObjectDestroyed(
                            target,
                            networkId);
                    }
                }
                break;

            case CommandCode.CmdTransform:
                {
                    if (connection.Player == null || connection.Room == null)
                        break;

                    uint networkId = reader.GetUInt();

                    float x = reader.GetFloat();
                    float y = reader.GetFloat();
                    float z = reader.GetFloat();

                    float rx = reader.GetFloat();
                    float ry = reader.GetFloat();
                    float rz = reader.GetFloat();
                    float rw = reader.GetFloat();

                    float vx = reader.GetFloat();
                    float vy = reader.GetFloat();
                    float vz = reader.GetFloat();

                    float avx = reader.GetFloat();
                    float avy = reader.GetFloat();
                    float avz = reader.GetFloat();

                    if (!server.World.TryGet(networkId, out NetworkObjectState obj))
                        break;

                    if (!ObjectBelongsToConnection(connection, obj))
                    {
                        server.RegisterViolation(connection, "network object outside room scope");
                        break;
                    }

                    bool allowed =
                        obj.OwnerPlayerId == connection.Player.PlayerId ||
                        (obj.LeaderCanControl && connection.Player.IsLeader);

                    if (!allowed)
                    {
                        Console.WriteLine($"[Security] {connection.Player.Username} attempted to move object {networkId} without authority.");
                        break;
                    }

                    if (
                        float.IsNaN(x) || float.IsNaN(y) || float.IsNaN(z) ||
                        float.IsNaN(rx) || float.IsNaN(ry) || float.IsNaN(rz) || float.IsNaN(rw) ||
                        float.IsNaN(vx) || float.IsNaN(vy) || float.IsNaN(vz) ||
                        float.IsNaN(avx) || float.IsNaN(avy) || float.IsNaN(avz) ||
                        float.IsInfinity(x) || float.IsInfinity(y) || float.IsInfinity(z) ||
                        float.IsInfinity(rx) || float.IsInfinity(ry) || float.IsInfinity(rz) || float.IsInfinity(rw) ||
                        float.IsInfinity(vx) || float.IsInfinity(vy) || float.IsInfinity(vz) ||
                        float.IsInfinity(avx) || float.IsInfinity(avy) || float.IsInfinity(avz))
                    {
                        Console.WriteLine($"[Security] Invalid transform from {connection.Player.Username}");
                        break;
                    }

                    obj.Position = new(x, y, z);
                    obj.Rotation = new(rx, ry, rz, rw);
                    obj.Velocity = new(vx, vy, vz);
                    obj.AngularVelocity = new(avx, avy, avz);

                    foreach (RelayPlayer player in connection.Room.ActivePlayers)
                    {
                        if (!IsObjectVisibleTo(obj, player.PlayerId))
                            continue;

                        RelayConnection? target = server.GetConnection(connection.Room, player);

                        if (target == null)
                            continue;

                        server.Events.ObjectTransform(
                            target,
                            networkId,
                            obj.Position.X,
                            obj.Position.Y,
                            obj.Position.Z,
                            obj.Rotation.X,
                            obj.Rotation.Y,
                            obj.Rotation.Z,
                            obj.Rotation.W,
                            obj.Velocity.X,
                            obj.Velocity.Y,
                            obj.Velocity.Z,
                            obj.AngularVelocity.X,
                            obj.AngularVelocity.Y,
                            obj.AngularVelocity.Z);
                    }

                    break;
                }

            case CommandCode.CmdRegisterNetworkVariables:
                {
                    if (connection.Player == null || connection.Room == null)
                        break;

                    uint networkId = reader.GetUInt();

                    if (!server.World.TryGet(networkId, out NetworkObjectState obj))
                        break;

                    if (!ObjectBelongsToConnection(connection, obj))
                    {
                        server.RegisterViolation(connection, "network object outside room scope");
                        break;
                    }

                    if (obj.OwnerPlayerId != connection.Player.PlayerId)
                        break;

                    ushort count = reader.GetUShort();
                    List<(ushort Id, NetworkVariableType Type, NetworkVariableAuthority Authority)> variables = new(count);

                    for (int i = 0; i < count; i++)
                    {
                        variables.Add((
                            reader.GetUShort(),
                            (NetworkVariableType)reader.GetByte(),
                            (NetworkVariableAuthority)reader.GetByte()));
                    }

                    ushort behaviourId = reader.AvailableBytes >= 2 ? reader.GetUShort() : (ushort)0;

                    if (!obj.RegisteredVariableBehaviours.Add(behaviourId))
                        break;

                    foreach (var variable in variables)
                    {
                        uint key = NetworkVariableKey(behaviourId, variable.Id);

                        obj.Variables[key] = new NetworkVariableState
                        {
                            Type = variable.Type,
                            Authority = variable.Authority
                        };
                    }

                    break;
                }

            case CommandCode.CmdNetworkVariable:
                {
                    if (connection.Player == null || connection.Room == null)
                        break;

                    uint networkId = reader.GetUInt();
                    ushort variableId = reader.GetUShort();

                    NetworkVariableType type =
                        (NetworkVariableType)reader.GetByte();

                    object value =
                        NetworkVariableSerializer.Read(reader, type);

                    ushort behaviourId = reader.AvailableBytes >= 2 ? reader.GetUShort() : (ushort)0;

                    if (!server.World.TryGet(networkId, out NetworkObjectState obj))
                        break;

                    if (!ObjectBelongsToConnection(connection, obj))
                    {
                        server.RegisterViolation(connection, "network object outside room scope");
                        break;
                    }

                    uint key = NetworkVariableKey(behaviourId, variableId);

                    if (!obj.Variables.TryGetValue(key, out NetworkVariableState variable))
                    {
                        server.RegisterViolation(connection,
                            "unknown network variable");

                        break;
                    }

                    if (variable.Type != type)
                    {
                        server.RegisterViolation(connection,
                            "network variable type mismatch");

                        break;
                    }

                    switch (variable.Authority)
                    {
                        case NetworkVariableAuthority.Owner:

                            if (obj.OwnerPlayerId != connection.Player.PlayerId)
                                break;

                            goto case NetworkVariableAuthority.Everyone;

                        case NetworkVariableAuthority.Leader:

                            if (!connection.Player.IsLeader)
                                break;

                            goto case NetworkVariableAuthority.Everyone;

                        case NetworkVariableAuthority.Server:

                            server.RegisterViolation(connection, "illegal server owned network variable write attempt");
                            break;

                        case NetworkVariableAuthority.Everyone:

                            obj.Values[key] = value;

                            foreach (RelayPlayer player in connection.Room.ActivePlayers)
                            {
                                if (!IsObjectVisibleTo(obj, player.PlayerId))
                                    continue;

                                RelayConnection target =
                                    server.GetConnection(connection.Room, player);

                                if (target == null)
                                    continue;

                                server.Events.NetworkVariable(
                                    target,
                                    networkId,
                                    variableId,
                                    type,
                                    value,
                                    behaviourId);
                            }

                            break;
                    }

                    break;
                }

            case CommandCode.CmdRegisterNetworkCollections:
                {
                    if (connection.Player == null || connection.Room == null)
                        break;

                    uint networkId = reader.GetUInt();
                    ushort behaviourId = reader.GetUShort();
                    ushort count = reader.GetUShort();

                    if (count > server.Options.MaxNetworkCollectionsPerBehaviour)
                    {
                        server.RegisterViolation(connection, "network collection count exceeded");
                        break;
                    }

                    if (!server.World.TryGet(networkId, out NetworkObjectState obj))
                        break;

                    if (!ObjectBelongsToConnection(connection, obj))
                    {
                        server.RegisterViolation(connection, "network object outside room scope");
                        break;
                    }

                    if (obj.OwnerPlayerId != connection.Player.PlayerId)
                    {
                        server.RegisterViolation(connection, "network collection registration without ownership");
                        break;
                    }

                    if (!obj.RegisteredCollectionBehaviours.Add(behaviourId))
                        break;

                    Dictionary<uint, NetworkCollectionState> registrations = new();
                    bool valid = true;

                    for (int i = 0; i < count; i++)
                    {
                        ushort collectionId = reader.GetUShort();
                        NetworkCollectionType collectionType = (NetworkCollectionType)reader.GetByte();
                        NetworkVariableAuthority authority = (NetworkVariableAuthority)reader.GetByte();
                        NetworkVariableType keyType = (NetworkVariableType)reader.GetByte();
                        NetworkVariableType valueType = (NetworkVariableType)reader.GetByte();
                        ushort itemCount = reader.GetUShort();

                        if (!Enum.IsDefined(typeof(NetworkCollectionType), collectionType) ||
                            !Enum.IsDefined(typeof(NetworkVariableAuthority), authority) ||
                            !Enum.IsDefined(typeof(NetworkVariableType), valueType) ||
                            (collectionType == NetworkCollectionType.Dictionary &&
                             !Enum.IsDefined(typeof(NetworkVariableType), keyType)) ||
                            itemCount > server.Options.MaxNetworkCollectionItems)
                        {
                            valid = false;
                            break;
                        }

                        uint key = NetworkCollectionKey(behaviourId, collectionId);

                        if (obj.Collections.ContainsKey(key) || registrations.ContainsKey(key))
                        {
                            valid = false;
                            break;
                        }

                        NetworkCollectionState state = new()
                        {
                            CollectionType = collectionType,
                            Authority = authority,
                            KeyType = keyType,
                            ValueType = valueType
                        };

                        for (int itemIndex = 0; itemIndex < itemCount; itemIndex++)
                        {
                            object collectionKey = null;

                            if (collectionType == NetworkCollectionType.Dictionary)
                                collectionKey = NetworkVariableSerializer.Read(reader, keyType);

                            object collectionValue = NetworkVariableSerializer.Read(reader, valueType);

                            switch (collectionType)
                            {
                                case NetworkCollectionType.List:
                                    state.List.Add(collectionValue);
                                    break;

                                case NetworkCollectionType.Dictionary:
                                    if (collectionKey == null || state.Dictionary.ContainsKey(collectionKey))
                                    {
                                        valid = false;
                                        break;
                                    }

                                    state.Dictionary.Add(collectionKey, collectionValue);
                                    break;

                                case NetworkCollectionType.Set:
                                    state.Set.Add(collectionValue);
                                    break;
                            }

                            if (!valid)
                                break;
                        }

                        if (!valid)
                            break;

                        registrations.Add(key, state);
                    }

                    if (!valid)
                    {
                        obj.RegisteredCollectionBehaviours.Remove(behaviourId);
                        server.RegisterViolation(connection, "invalid network collection registration");
                        break;
                    }

                    foreach (KeyValuePair<uint, NetworkCollectionState> registration in registrations)
                        obj.Collections.Add(registration.Key, registration.Value);

                    foreach (RelayPlayer player in connection.Room.ActivePlayers)
                    {
                        if (player.PlayerId == connection.Player.PlayerId)
                            continue;

                        if (!IsObjectVisibleTo(obj, player.PlayerId))
                            continue;

                        RelayConnection? target = server.GetConnection(connection.Room, player);

                        if (target == null || target.ProtocolVersion < 2)
                            continue;

                        foreach (KeyValuePair<uint, NetworkCollectionState> registration in registrations)
                        {
                            ushort registeredBehaviourId = (ushort)(registration.Key >> 16);
                            ushort registeredCollectionId = (ushort)registration.Key;

                            SendNetworkCollectionSnapshot(
                                server,
                                obj,
                                target,
                                registeredBehaviourId,
                                registeredCollectionId,
                                registration.Value,
                                0);
                        }
                    }

                    break;
                }

            case CommandCode.CmdNetworkCollection:
                {
                    if (connection.Player == null || connection.Room == null)
                        break;

                    if (!connection.CollectionRate.TryConsume())
                    {
                        server.RegisterViolation(connection, "network collection rate exceeded");
                        break;
                    }

                    uint networkId = reader.GetUInt();
                    ushort behaviourId = reader.GetUShort();
                    ushort collectionId = reader.GetUShort();
                    NetworkCollectionType requestedType = (NetworkCollectionType)reader.GetByte();
                    NetworkCollectionOperation operation = (NetworkCollectionOperation)reader.GetByte();
                    uint requestId = reader.GetUInt();

                    if (!server.World.TryGet(networkId, out NetworkObjectState obj))
                        break;

                    if (!ObjectBelongsToConnection(connection, obj))
                    {
                        server.RegisterViolation(connection, "network object outside room scope");
                        break;
                    }

                    if (!IsObjectVisibleTo(obj, connection.Player.PlayerId))
                    {
                        server.RegisterViolation(connection, "network collection write on hidden object");
                        break;
                    }

                    uint key = NetworkCollectionKey(behaviourId, collectionId);

                    if (!obj.Collections.TryGetValue(key, out NetworkCollectionState state))
                    {
                        server.RegisterViolation(connection, "unknown network collection");
                        break;
                    }

                    if (state.CollectionType != requestedType ||
                        !Enum.IsDefined(typeof(NetworkCollectionOperation), operation))
                    {
                        server.RegisterViolation(connection, "network collection type mismatch");
                        break;
                    }

                    bool allowed = state.Authority switch
                    {
                        NetworkVariableAuthority.Owner => obj.OwnerPlayerId == connection.Player.PlayerId,
                        NetworkVariableAuthority.Leader => connection.Player.IsLeader,
                        NetworkVariableAuthority.Everyone => true,
                        _ => false
                    };

                    if (!allowed)
                    {
                        server.RegisterViolation(connection, "network collection write without authority");
                        break;
                    }

                    bool applied = false;
                    int index = -1;
                    object collectionKey = null;
                    object collectionValue = null;

                    switch (state.CollectionType)
                    {
                        case NetworkCollectionType.List:
                            switch (operation)
                            {
                                case NetworkCollectionOperation.Add:
                                    collectionValue = NetworkVariableSerializer.Read(reader, state.ValueType);

                                    if (state.List.Count < server.Options.MaxNetworkCollectionItems)
                                    {
                                        index = state.List.Count;
                                        state.List.Add(collectionValue);
                                        applied = true;
                                    }
                                    break;

                                case NetworkCollectionOperation.Insert:
                                    index = reader.GetInt();
                                    collectionValue = NetworkVariableSerializer.Read(reader, state.ValueType);

                                    if (state.List.Count < server.Options.MaxNetworkCollectionItems &&
                                        index >= 0 &&
                                        index <= state.List.Count)
                                    {
                                        state.List.Insert(index, collectionValue);
                                        applied = true;
                                    }
                                    break;

                                case NetworkCollectionOperation.Set:
                                    index = reader.GetInt();
                                    collectionValue = NetworkVariableSerializer.Read(reader, state.ValueType);

                                    if (index >= 0 && index < state.List.Count)
                                    {
                                        state.List[index] = collectionValue;
                                        applied = true;
                                    }
                                    break;

                                case NetworkCollectionOperation.RemoveAt:
                                    index = reader.GetInt();

                                    if (index >= 0 && index < state.List.Count)
                                    {
                                        state.List.RemoveAt(index);
                                        applied = true;
                                    }
                                    break;

                                case NetworkCollectionOperation.Clear:
                                    state.List.Clear();
                                    applied = true;
                                    break;
                            }
                            break;

                        case NetworkCollectionType.Dictionary:
                            switch (operation)
                            {
                                case NetworkCollectionOperation.Add:
                                    collectionKey = NetworkVariableSerializer.Read(reader, state.KeyType);
                                    collectionValue = NetworkVariableSerializer.Read(reader, state.ValueType);

                                    if (collectionKey != null &&
                                        state.Dictionary.Count < server.Options.MaxNetworkCollectionItems &&
                                        !state.Dictionary.ContainsKey(collectionKey))
                                    {
                                        state.Dictionary.Add(collectionKey, collectionValue);
                                        applied = true;
                                    }
                                    break;

                                case NetworkCollectionOperation.Set:
                                    collectionKey = NetworkVariableSerializer.Read(reader, state.KeyType);
                                    collectionValue = NetworkVariableSerializer.Read(reader, state.ValueType);

                                    if (collectionKey != null &&
                                        (state.Dictionary.ContainsKey(collectionKey) ||
                                         state.Dictionary.Count < server.Options.MaxNetworkCollectionItems))
                                    {
                                        state.Dictionary[collectionKey] = collectionValue;
                                        applied = true;
                                    }
                                    break;

                                case NetworkCollectionOperation.Remove:
                                    collectionKey = NetworkVariableSerializer.Read(reader, state.KeyType);

                                    if (collectionKey != null)
                                        applied = state.Dictionary.Remove(collectionKey);
                                    break;

                                case NetworkCollectionOperation.Clear:
                                    state.Dictionary.Clear();
                                    applied = true;
                                    break;
                            }
                            break;

                        case NetworkCollectionType.Set:
                            switch (operation)
                            {
                                case NetworkCollectionOperation.Add:
                                    collectionValue = NetworkVariableSerializer.Read(reader, state.ValueType);

                                    if (state.Set.Contains(collectionValue))
                                    {
                                        applied = true;
                                    }
                                    else if (state.Set.Count < server.Options.MaxNetworkCollectionItems)
                                    {
                                        state.Set.Add(collectionValue);
                                        applied = true;
                                    }
                                    break;

                                case NetworkCollectionOperation.Remove:
                                    collectionValue = NetworkVariableSerializer.Read(reader, state.ValueType);
                                    applied = state.Set.Remove(collectionValue);
                                    break;

                                case NetworkCollectionOperation.Clear:
                                    state.Set.Clear();
                                    applied = true;
                                    break;
                            }
                            break;
                    }

                    if (applied)
                    {
                        NetworkCollectionData delta = new(
                            networkId,
                            behaviourId,
                            collectionId,
                            state.CollectionType,
                            operation,
                            requestId,
                            state.KeyType,
                            state.ValueType,
                            index,
                            collectionKey,
                            collectionValue,
                            Array.Empty<NetworkCollectionEntry>());

                        foreach (RelayPlayer player in connection.Room.ActivePlayers)
                        {
                            if (player.PlayerId == connection.Player.PlayerId)
                                continue;

                            if (!IsObjectVisibleTo(obj, player.PlayerId))
                                continue;

                            RelayConnection? target = server.GetConnection(connection.Room, player);

                            if (target == null || target.ProtocolVersion < 2)
                                continue;

                            server.Events.NetworkCollection(target, delta);
                        }
                    }

                    SendNetworkCollectionSnapshot(
                        server,
                        obj,
                        connection,
                        behaviourId,
                        collectionId,
                        state,
                        requestId);

                    break;
                }

            case CommandCode.CmdRegisterRpcs:
                {
                    if (connection.Player == null || connection.Room == null)
                        break;

                    uint networkId = reader.GetUInt();

                    if (!server.World.TryGet(networkId, out NetworkObjectState obj))
                        break;

                    if (!ObjectBelongsToConnection(connection, obj))
                    {
                        server.RegisterViolation(connection, "network object outside room scope");
                        break;
                    }

                    if (obj.RpcsRegistered)
                        break;

                    if (obj.OwnerPlayerId != connection.Player.PlayerId)
                        break;

                    ushort count = reader.GetUShort();

                    for (int i = 0; i < count; i++)
                    {
                        ushort behaviourId = reader.GetUShort();
                        ushort methodId = reader.GetUShort();
                        RpcCaller caller = (RpcCaller)reader.GetByte();
                        DeliveryMethod delivery = (DeliveryMethod)reader.GetByte();

                        RpcRegistry.Register(
                            $"nid{networkId}:b{behaviourId}:m{methodId}",
                            behaviourId,
                            methodId,
                            caller,
                            delivery);
                    }

                    obj.RpcsRegistered = true;

                    Console.WriteLine($"[Rpc] Registered {count} rpc(s) for network object {networkId} (owner {connection.Player.Username})");

                    break;
                }

            case CommandCode.CmdRpc:
                {
                    if (connection.Player == null || connection.Room == null)
                        break;

                    if (!connection.RpcRate.TryConsume())
                    {
                        server.RegisterViolation(connection, "rpc rate exceeded");
                        break;
                    }

                    RpcData rpc = RpcSerializer.ReadRequest(reader);
                    bool buffered = rpc.Target == RpcTarget.AllBuffered || rpc.Target == RpcTarget.OthersBuffered;

                    rpc.SenderPlayerId = connection.Player.PlayerId;
                    rpc.IsLeader = connection.Player.IsLeader;
                    rpc.Tick = server.Clock.CurrentTick;

                    if (rpc.Parameters.Length > server.Options.MaxRpcParameters)
                    {
                        server.RegisterViolation(connection, "rpc parameter count exceeded");
                        break;
                    }

                    if (!server.World.TryGet(rpc.NetworkId, out NetworkObjectState obj))
                    {
                        server.RegisterViolation(connection, "rpc on unknown network object");
                        break;
                    }

                    if (!ObjectBelongsToConnection(connection, obj))
                    {
                        server.RegisterViolation(connection, "network object outside room scope");
                        break;
                    }

                    if (!RpcRegistry.TryGetByIds(rpc.BehaviourId, rpc.MethodId, out RpcMetadata? metadata) || metadata == null)
                    {
                        server.RegisterViolation(connection, "rpc on unregistered method");
                        break;
                    }

                    bool allowed = metadata.Caller switch
                    {
                        RpcCaller.Anyone => true,
                        RpcCaller.Owner => obj.OwnerPlayerId == connection.Player.PlayerId,
                        RpcCaller.Leader => connection.Player.IsLeader,
                        _ => false
                    };

                    if (!allowed)
                    {
                        server.RegisterViolation(
                            connection,
                            $"illegal rpc caller for behaviour {rpc.BehaviourId} method {rpc.MethodId}");

                        break;
                    }

                    // Delivery is server authoritative; never trust the client's wire value.
                    rpc.Delivery = metadata.Delivery;

                    if (buffered)
                    {
                        obj.BufferedRpcs.Add(new BufferedRpc
                        {
                            Rpc = new RpcData
                            {
                                NetworkId = rpc.NetworkId,
                                BehaviourId = rpc.BehaviourId,
                                MethodId = rpc.MethodId,
                                SenderPlayerId = rpc.SenderPlayerId,
                                IsLeader = rpc.IsLeader,
                                Tick = rpc.Tick,
                                Delivery = DeliveryMethod.ReliableOrdered,
                                Target = rpc.Target,
                                HasSpecificTarget = rpc.HasSpecificTarget,
                                SpecificTargetPlayerId = rpc.SpecificTargetPlayerId,
                                Parameters = (object[])rpc.Parameters.Clone()
                            }
                        });

                        switch (rpc.Target)
                        {
                            case RpcTarget.AllBuffered:
                                rpc.Target = RpcTarget.All;
                                break;

                            case RpcTarget.OthersBuffered:
                                rpc.Target = RpcTarget.Others;
                                break;

                        }
                    }
                    if (rpc.HasSpecificTarget)
                    {
                        RelayPlayer? targetPlayer = connection.Room.ActivePlayers
                            .FirstOrDefault(player => player.PlayerId == rpc.SpecificTargetPlayerId);

                        if (targetPlayer == null)
                            break;

                        if (!IsObjectVisibleTo(obj, targetPlayer.PlayerId))
                            break;

                        RelayConnection? targetConnection = server.GetConnection(connection.Room, targetPlayer);

                        if (targetConnection == null)
                            break;

                        server.Events.Rpc(targetConnection, rpc);

                        break;
                    }

                    switch (rpc.Target)
                    {
                        case RpcTarget.All:
                            {
                                foreach (RelayPlayer player in connection.Room.ActivePlayers)
                                {
                                    if (!IsObjectVisibleTo(obj, player.PlayerId))
                                        continue;

                                    RelayConnection? target = server.GetConnection(connection.Room, player);

                                    if (target == null)
                                        continue;

                                    server.Events.Rpc(target, rpc);
                                }

                                break;
                            }

                        case RpcTarget.Others:
                            {
                                foreach (RelayPlayer player in connection.Room.ActivePlayers)
                                {
                                    if (player == connection.Player)
                                        continue;

                                    if (!IsObjectVisibleTo(obj, player.PlayerId))
                                        continue;

                                    RelayConnection? target = server.GetConnection(connection.Room, player);

                                    if (target == null)
                                        continue;

                                    server.Events.Rpc(target, rpc);
                                }

                                break;
                            }

                        case RpcTarget.Leader:
                            {
                                RelayPlayer? leader = connection.Room.Leader;

                                if (leader == null)
                                    break;

                                if (!IsObjectVisibleTo(obj, leader.PlayerId))
                                    break;

                                RelayConnection? target = server.GetConnection(connection.Room, leader);

                                if (target == null)
                                    break;

                                server.Events.Rpc(target, rpc);

                                break;
                            }
                    }

                    break;
                }

            case CommandCode.CmdClearBufferedRpcs:
                {
                    if (connection.Player == null || connection.Room == null)
                        break;

                    uint networkId = reader.GetUInt();

                    if (!server.World.TryGet(networkId, out NetworkObjectState obj))
                        break;

                    if (!ObjectBelongsToConnection(connection, obj))
                    {
                        server.RegisterViolation(connection, "network object outside room scope");
                        break;
                    }

                    bool allowed =
                        obj.OwnerPlayerId == connection.Player.PlayerId ||
                        connection.Player.IsLeader;

                    if (!allowed)
                    {
                        server.RegisterViolation(connection, "attempted to clear buffered rpcs without authority", true);
                        break;
                    }

                    obj.BufferedRpcs.Clear();

                    break;
                }

            case CommandCode.CmdClearBufferedRpc:
                {
                    if (connection.Player == null || connection.Room == null)
                        break;

                    uint networkId = reader.GetUInt();
                    ushort behaviourId = reader.GetUShort();
                    ushort methodId = reader.GetUShort();

                    if (!server.World.TryGet(networkId, out NetworkObjectState obj))
                        break;

                    if (!ObjectBelongsToConnection(connection, obj))
                    {
                        server.RegisterViolation(connection, "network object outside room scope");
                        break;
                    }

                    bool allowed =
                        obj.OwnerPlayerId == connection.Player.PlayerId ||
                        connection.Player.IsLeader;

                    if (!allowed)
                    {
                        server.RegisterViolation(connection, "attempted to clear buffered rpc without authority", true);
                        break;
                    }

                    obj.BufferedRpcs.RemoveAll(x =>
                        x.Rpc.BehaviourId == behaviourId &&
                        x.Rpc.MethodId == methodId);

                    break;
                }

            case CommandCode.CmdClearAllBufferedRpcs:
                {
                    if (connection.Player == null || connection.Room == null)
                        break;

                    if (!connection.Player.IsLeader)
                    {
                        server.RegisterViolation(connection, "attempted to clear all buffered rpcs without being leader", true);
                        break;
                    }

                    foreach (NetworkObjectState obj in server.World.Objects)
                    {
                        if (obj.Room != connection.Room ||
                            !string.Equals(obj.AppId, connection.AppId, StringComparison.OrdinalIgnoreCase))
                        {
                            continue;
                        }

                        obj.BufferedRpcs.Clear();
                    }

                    break;
                }

            case CommandCode.CmdDropConnection:
                {
                    if (connection.Player == null || connection.Room == null)
                        break;

                    if (!connection.Player.IsLeader)
                    {
                        server.RegisterViolation(connection, "attempted to drop connection without being leader");
                        break;
                    }

                    int playerId = reader.GetInt();

                    RelayPlayer? player = connection.Room.ActivePlayers
                        .FirstOrDefault(activePlayer => activePlayer.PlayerId == playerId);

                    if (player == null)
                        break;

                    RelayConnection? target = server.GetConnection(connection.Room, player);

                    if (target == null)
                        break;

                    if (target.Room != connection.Room ||
                        !string.Equals(target.AppId, connection.AppId, StringComparison.OrdinalIgnoreCase))
                    {
                        server.RegisterViolation(connection, "attempted to drop connection outside room scope", true);
                        break;
                    }

                    server.Events.DropConnection(target);
                    break;
                }

            case CommandCode.CmdTransferLeader:
                {
                    if (connection.Player == null || connection.Room == null)
                        break;

                    if (!connection.Player.IsLeader)
                    {
                        server.RegisterViolation(connection, "attempted to transfer leader without being leader", true);
                        break;
                    }

                    int playerId = reader.GetInt();

                    RelayPlayer? newLeader = connection.Room.ActivePlayers.FirstOrDefault(player => player.PlayerId == playerId);

                    if (newLeader == null)
                        break;

                    if (newLeader == connection.Player)
                        break;

                    connection.Player.IsLeader = false;
                    newLeader.IsLeader = true;
                    connection.Room.Leader = newLeader;

                    foreach (RelayPlayer player in connection.Room.ActivePlayers)
                    {
                        RelayConnection? target = server.GetConnection(connection.Room, player);

                        if (target == null)
                            continue;

                        server.Events.LeaderChanged(target, newLeader);
                    }

                    break;
                }

            case CommandCode.CmdTransferOwnership:
                {
                    if (connection.Player == null || connection.Room == null)
                        break;

                    uint networkId = reader.GetUInt();
                    int newOwnerPlayerId = reader.GetInt();

                    if (!server.World.TryGet(networkId, out NetworkObjectState obj))
                        break;

                    if (!ObjectBelongsToConnection(connection, obj))
                    {
                        server.RegisterViolation(connection, "network object outside room scope");
                        break;
                    }

                    bool allowed =
                        obj.OwnerPlayerId == connection.Player.PlayerId ||
                        (obj.LeaderCanControl && connection.Player.IsLeader);

                    if (!allowed)
                    {
                        server.RegisterViolation(connection, "attempted ownership transfer without authority");
                        break;
                    }

                    RelayPlayer? newOwner = connection.Room.ActivePlayers
                        .FirstOrDefault(player => player.PlayerId == newOwnerPlayerId);

                    if (newOwner == null)
                        break;

                    bool newOwnerWasVisible = IsObjectVisibleTo(obj, newOwner.PlayerId);

                    obj.OwnerPlayerId = newOwner.PlayerId;

                    if (obj.InterestBased && !newOwnerWasVisible)
                    {
                        obj.InterestedPlayerIds.Add(newOwner.PlayerId);

                        RelayConnection? newOwnerConnection =
                            server.GetConnection(connection.Room, newOwner);

                        if (newOwnerConnection != null)
                            SendObjectStateTo(server, obj, newOwnerConnection);
                    }

                    foreach (RelayPlayer player in connection.Room.ActivePlayers)
                    {
                        if (!IsObjectVisibleTo(obj, player.PlayerId))
                            continue;

                        RelayConnection? target =
                            server.GetConnection(connection.Room, player);

                        if (target == null)
                            continue;

                        server.Events.OwnershipChanged(
                            target,
                            networkId,
                            newOwner.PlayerId);
                    }

                    break;
                }
            case CommandCode.CmdSetPlayerInterest:
                {
                    if (connection.Player == null || connection.Room == null)
                        break;

                    uint networkId = reader.GetUInt();
                    int playerId = reader.GetInt();
                    bool interested = reader.GetBool();

                    Console.WriteLine($"[Server] CmdSetPlayerInterest from {connection.Player.Username}: networkId={networkId} playerId={playerId} interested={interested}");

                    if (!server.World.TryGet(networkId, out NetworkObjectState obj))
                    {
                        Console.WriteLine($"[Server] CmdSetPlayerInterest: networkId {networkId} not found");
                        break;
                    }

                    if (!ObjectBelongsToConnection(connection, obj))
                    {
                        Console.WriteLine($"[Server] CmdSetPlayerInterest: networkId {networkId} outside room/AppId scope");
                        server.RegisterViolation(connection, "network object outside room scope");
                        break;
                    }

                    if (!obj.InterestBased)
                    {
                        Console.WriteLine($"[Server] CmdSetPlayerInterest: networkId {networkId} is not interest based");
                        break;
                    }

                    bool authorized = obj.OwnerPlayerId == connection.Player.PlayerId || connection.Player.IsLeader;

                    if (!authorized)
                    {
                        Console.WriteLine($"[Server] CmdSetPlayerInterest: {connection.Player.Username} not authorized (owner={obj.OwnerPlayerId}, isLeader={connection.Player.IsLeader})");
                        server.RegisterViolation(connection, "interest change without authority");
                        break;
                    }

                    RelayPlayer? target = connection.Room.ActivePlayers.FirstOrDefault(p => p.PlayerId == playerId);

                    if (target == null)
                    {
                        Console.WriteLine($"[Server] CmdSetPlayerInterest: target player {playerId} not in room");
                        break;
                    }

                    RelayConnection? targetConnection = server.GetConnection(connection.Room, target);

                    if (targetConnection == null || !string.Equals(targetConnection.AppId, connection.AppId, StringComparison.OrdinalIgnoreCase))
                    {
                        Console.WriteLine($"[Server] CmdSetPlayerInterest: target player {playerId} has no matching connection");
                        break;
                    }

                    if (interested)
                    {
                        if (!obj.InterestedPlayerIds.Add(playerId))
                        {
                            Console.WriteLine($"[Server] CmdSetPlayerInterest: player {playerId} already interested in {networkId}");
                            break;
                        }

                        Console.WriteLine($"[Server] CmdSetPlayerInterest: sending object state for {networkId} to {target.Username}");

                        SendObjectStateTo(server, obj, targetConnection);
                    }
                    else
                    {
                        if (playerId == obj.OwnerPlayerId)
                        {
                            server.RegisterViolation(connection, "attempted to remove object owner from interest");
                            break;
                        }

                        if (!obj.InterestedPlayerIds.Remove(playerId))
                        {
                            Console.WriteLine($"[Server] CmdSetPlayerInterest: player {playerId} was not interested in {networkId}");
                            break;
                        }

                        Console.WriteLine($"[Server] CmdSetPlayerInterest: hiding {networkId} from {target.Username}");

                        server.Events.ObjectHidden(targetConnection, obj.NetworkId);
                    }

                    break;
                }
            case CommandCode.CmdLoadScene:
                {
                    if (connection.Player == null || connection.Room == null)
                        break;

                    string sceneName = reader.GetString().Trim();

                    if (sceneName.Length == 0 || sceneName.Length > MaxSceneNameLength)
                    {
                        server.RegisterViolation(connection, "invalid scene name");
                        break;
                    }

                    if (!string.Equals(connection.Room.AppId, connection.AppId, StringComparison.OrdinalIgnoreCase))
                    {
                        server.RegisterViolation(connection, "scene load outside app scope");
                        break;
                    }

                    if (connection.Room.Leader != connection.Player)
                    {
                        server.RegisterViolation(connection, "scene load without leader authority");
                        break;
                    }

                    if (string.Equals(connection.Room.CurrentScene, sceneName, StringComparison.Ordinal))
                        break;

                    int currentBytes = GetRoomPropertyEstimatedSize(connection.Room);
                    string oldScene = connection.Room.CurrentScene;
                    int newBytes = currentBytes - oldScene.Length * sizeof(char) + sceneName.Length * sizeof(char);

                    if (newBytes > server.Options.MaxRoomPropertyBytes)
                    {
                        server.RegisterViolation(connection, "room property limit exceeded by scene name");
                        break;
                    }

                    connection.Room.Properties[RoomProperties.CurrentSceneKey] = sceneName;

                    PropertyChanges sceneChanges = new();
                    sceneChanges[RoomProperties.CurrentSceneKey] = sceneName;

                    foreach (RelayPlayer player in connection.Room.ActivePlayers)
                    {
                        RelayConnection? target = server.GetConnection(connection.Room, player);

                        if (target == null)
                            continue;

                        if (!string.Equals(target.AppId, connection.AppId, StringComparison.OrdinalIgnoreCase))
                            continue;

                        target.SceneReady = false;
                        server.Events.RoomProperties(target, connection.Room, sceneChanges);
                        server.Events.SceneLoad(target, sceneName);
                    }

                    break;
                }
            case CommandCode.CmdSceneReady:
                {
                    if (connection.Player == null || connection.Room == null)
                        break;

                    string sceneName = reader.GetString().Trim();

                    if (sceneName.Length == 0 || sceneName.Length > MaxSceneNameLength)
                    {
                        server.RegisterViolation(connection, "invalid scene ready name");
                        break;
                    }

                    if (!string.Equals(connection.Room.AppId, connection.AppId, StringComparison.OrdinalIgnoreCase))
                    {
                        server.RegisterViolation(connection, "scene ready outside app scope");
                        break;
                    }

                    if (!string.Equals(connection.Room.CurrentScene, sceneName, StringComparison.Ordinal))
                    {
                        server.RegisterViolation(connection, "scene ready mismatch");
                        break;
                    }

                    if (connection.SceneReady)
                        break;

                    connection.SceneReady = true;
                    SyncSceneState(server, connection);
                    break;
                }
            case CommandCode.CmdChildTransform:
                {
                    if (connection.Player == null || connection.Room == null)
                        break;

                    uint networkId = reader.GetUInt();
                    byte count = reader.GetByte();

                    if (count == 0 || count > 64)
                    {
                        server.RegisterViolation(connection, "invalid child transform count");
                        break;
                    }

                    if (!server.World.TryGet(networkId, out NetworkObjectState obj))
                        break;

                    if (!ObjectBelongsToConnection(connection, obj))
                    {
                        server.RegisterViolation(connection, "network object outside room scope");
                        break;
                    }

                    bool allowed =
                        obj.OwnerPlayerId == connection.Player.PlayerId ||
                        (obj.LeaderCanControl && connection.Player.IsLeader);

                    if (!allowed)
                    {
                        server.RegisterViolation(connection, "attempted to move child transform without authority");
                        break;
                    }

                    byte[] indices = new byte[count];
                    Vector3[] positions = new Vector3[count];
                    Quaternion[] rotations = new Quaternion[count];
                    bool valid = true;

                    for (int i = 0; i < count; i++)
                    {
                        byte index = reader.GetByte();

                        float x = reader.GetFloat();
                        float y = reader.GetFloat();
                        float z = reader.GetFloat();

                        float rx = reader.GetFloat();
                        float ry = reader.GetFloat();
                        float rz = reader.GetFloat();
                        float rw = reader.GetFloat();

                        if (index >= obj.ChildTransformCount ||
                            float.IsNaN(x) || float.IsNaN(y) || float.IsNaN(z) ||
                            float.IsNaN(rx) || float.IsNaN(ry) || float.IsNaN(rz) || float.IsNaN(rw) ||
                            float.IsInfinity(x) || float.IsInfinity(y) || float.IsInfinity(z) ||
                            float.IsInfinity(rx) || float.IsInfinity(ry) || float.IsInfinity(rz) || float.IsInfinity(rw))
                        {
                            valid = false;
                            continue;
                        }

                        indices[i] = index;
                        positions[i] = new Vector3(x, y, z);
                        rotations[i] = new Quaternion(rx, ry, rz, rw);
                    }

                    if (!valid)
                    {
                        server.RegisterViolation(connection, "invalid child transform data");
                        break;
                    }

                    for (int i = 0; i < count; i++)
                    {
                        obj.ChildPositions[indices[i]] = positions[i];
                        obj.ChildRotations[indices[i]] = rotations[i];
                        obj.ChildTransformReceived[indices[i]] = true;
                    }

                    foreach (RelayPlayer player in connection.Room.ActivePlayers)
                    {
                        if (!IsObjectVisibleTo(obj, player.PlayerId))
                            continue;

                        RelayConnection? target = server.GetConnection(connection.Room, player);

                        if (target == null)
                            continue;

                        server.Events.ChildTransform(target, networkId, indices, positions, rotations);
                    }

                    break;
                }
            default:
                {
                    Console.WriteLine($"[Server] Unknown command ({code}, raw={(ushort)code})");

                    break;
                }
        }
    }

    private static uint NetworkVariableKey(ushort behaviourId, ushort variableId)
    {
        return ((uint)behaviourId << 16) | variableId;
    }

    private static uint NetworkCollectionKey(ushort behaviourId, ushort collectionId)
    {
        return ((uint)behaviourId << 16) | collectionId;
    }

    private static void SendNetworkCollectionStateTo(
        RelayServer server,
        NetworkObjectState obj,
        RelayConnection connection)
    {
        if (connection.ProtocolVersion < 2)
            return;

        foreach (KeyValuePair<uint, NetworkCollectionState> collection in obj.Collections)
        {
            ushort behaviourId = (ushort)(collection.Key >> 16);
            ushort collectionId = (ushort)collection.Key;

            SendNetworkCollectionSnapshot(
                server,
                obj,
                connection,
                behaviourId,
                collectionId,
                collection.Value,
                0);
        }
    }

    private static void SendNetworkCollectionSnapshot(
        RelayServer server,
        NetworkObjectState obj,
        RelayConnection connection,
        ushort behaviourId,
        ushort collectionId,
        NetworkCollectionState state,
        uint requestId)
    {
        if (connection.ProtocolVersion < 2)
            return;

        NetworkCollectionEntry[] entries;

        switch (state.CollectionType)
        {
            case NetworkCollectionType.List:
                entries = new NetworkCollectionEntry[state.List.Count];

                for (int i = 0; i < state.List.Count; i++)
                    entries[i] = new NetworkCollectionEntry(null, state.List[i]);

                break;

            case NetworkCollectionType.Dictionary:
                entries = new NetworkCollectionEntry[state.Dictionary.Count];

                int dictionaryIndex = 0;

                foreach (KeyValuePair<object, object> item in state.Dictionary)
                    entries[dictionaryIndex++] = new NetworkCollectionEntry(item.Key, item.Value);

                break;

            case NetworkCollectionType.Set:
                entries = new NetworkCollectionEntry[state.Set.Count];

                int setIndex = 0;

                foreach (object item in state.Set)
                    entries[setIndex++] = new NetworkCollectionEntry(null, item);

                break;

            default:
                return;
        }

        server.Events.NetworkCollection(
            connection,
            new NetworkCollectionData(
                obj.NetworkId,
                behaviourId,
                collectionId,
                state.CollectionType,
                NetworkCollectionOperation.Snapshot,
                requestId,
                state.KeyType,
                state.ValueType,
                -1,
                null,
                null,
                entries));
    }

    private static int GetRoomPropertyEstimatedSize(Room room)
    {
        int bytes = 0;

        foreach (var property in room.Properties)
        {
            bytes += property.Key.Length * sizeof(char);

            if (property.Value is string value)
                bytes += value.Length * sizeof(char);
        }

        return bytes;
    }

    private static void SyncSceneState(RelayServer server, RelayConnection connection)
    {
        if (connection.Room == null || connection.Player == null)
            return;

        foreach (NetworkObjectState obj in server.World.Objects)
        {
            if (obj.Room != connection.Room || !string.Equals(obj.AppId, connection.AppId, StringComparison.OrdinalIgnoreCase))
                continue;

            if (!IsObjectVisibleTo(obj, connection.Player.PlayerId))
                continue;

            SendObjectStateTo(server, obj, connection);
        }
    }

    private static bool ObjectBelongsToConnection(RelayConnection connection, NetworkObjectState obj)
    {
        return connection.Room != null &&
               obj.Room == connection.Room &&
               string.Equals(obj.AppId, connection.AppId, StringComparison.OrdinalIgnoreCase);
    }

    private static bool IsObjectVisibleTo(NetworkObjectState obj, int playerId)
    {
        return !obj.InterestBased || obj.InterestedPlayerIds.Contains(playerId);
    }

    private static void AllocateChildTransforms(NetworkObjectState obj)
    {
        if (obj.ChildTransformCount == 0)
            return;

        obj.ChildPositions = new Vector3[obj.ChildTransformCount];
        obj.ChildRotations = new Quaternion[obj.ChildTransformCount];
        obj.ChildTransformReceived = new bool[obj.ChildTransformCount];

        for (int i = 0; i < obj.ChildTransformCount; i++)
            obj.ChildRotations[i] = Quaternion.Identity;
    }

    private static void SendChildTransformStateTo(RelayServer server, NetworkObjectState obj, RelayConnection connection)
    {
        if (obj.ChildTransformCount == 0)
            return;

        int count = 0;

        for (int i = 0; i < obj.ChildTransformCount; i++)
        {
            if (obj.ChildTransformReceived[i])
                count++;
        }

        if (count == 0)
            return;

        byte[] indices = new byte[count];
        Vector3[] positions = new Vector3[count];
        Quaternion[] rotations = new Quaternion[count];

        int writeIndex = 0;

        for (byte i = 0; i < obj.ChildTransformCount; i++)
        {
            if (!obj.ChildTransformReceived[i])
                continue;

            indices[writeIndex] = i;
            positions[writeIndex] = obj.ChildPositions[i];
            rotations[writeIndex] = obj.ChildRotations[i];
            writeIndex++;
        }

        server.Events.ChildTransform(connection, obj.NetworkId, indices, positions, rotations);
    }

    private static void ReplayBufferedRpcs(RelayServer server, NetworkObjectState obj, RelayConnection connection)
    {
        if (connection.Player == null)
            return;

        foreach (BufferedRpc bufferedRpc in obj.BufferedRpcs)
        {
            if (bufferedRpc.Rpc.Target == RpcTarget.OthersBuffered &&
                bufferedRpc.Rpc.SenderPlayerId == connection.Player.PlayerId)
            {
                continue;
            }

            server.Events.Rpc(connection, bufferedRpc.Rpc);
        }
    }

    private static void SendObjectStateTo(RelayServer server, NetworkObjectState obj, RelayConnection connection)
    {
        server.Events.ObjectSpawned(
            connection,
            obj.PrefabId,
            obj.NetworkId,
            obj.OwnerPlayerId,
            obj.IsPlayer,
            obj.Position.X,
            obj.Position.Y,
            obj.Position.Z,
            obj.Rotation.X,
            obj.Rotation.Y,
            obj.Rotation.Z,
            obj.Rotation.W);

        server.Events.ObjectTransform(
            connection,
            obj.NetworkId,
            obj.Position.X,
            obj.Position.Y,
            obj.Position.Z,
            obj.Rotation.X,
            obj.Rotation.Y,
            obj.Rotation.Z,
            obj.Rotation.W,
            obj.Velocity.X,
            obj.Velocity.Y,
            obj.Velocity.Z,
            obj.AngularVelocity.X,
            obj.AngularVelocity.Y,
            obj.AngularVelocity.Z);

        SendChildTransformStateTo(server, obj, connection);

        foreach (KeyValuePair<uint, object> value in obj.Values)
        {
            if (!obj.Variables.TryGetValue(value.Key, out NetworkVariableState? variable))
                continue;

            ushort behaviourId = (ushort)(value.Key >> 16);
            ushort variableId = (ushort)value.Key;

            server.Events.NetworkVariable(
                connection,
                obj.NetworkId,
                variableId,
                variable.Type,
                value.Value,
                behaviourId);
        }

        SendNetworkCollectionStateTo(server, obj, connection);
        ReplayBufferedRpcs(server, obj, connection);
    }

    private void SyncReclaimedSession(RelayServer server, RelayConnection connection)
    {
        if (connection.Room == null || connection.Player == null)
            return;

        Room room = connection.Room;

        connection.SceneReady = string.IsNullOrEmpty(room.CurrentScene);

        server.Events.RoomJoined(connection, room);

        foreach (RelayPlayer player in room.ActivePlayers)
            server.Events.PlayerSync(connection, player);

        PropertyChanges roomProperties = new();

        foreach (var property in room.Properties)
            roomProperties[property.Key] = property.Value;

        server.Events.RoomProperties(connection, room, roomProperties);

        foreach (NetworkObjectState obj in server.World.Objects)
        {
            if (obj.Room != room || !string.Equals(obj.AppId, connection.AppId, StringComparison.OrdinalIgnoreCase))
                continue;

            if (!IsObjectVisibleTo(obj, connection.Player.PlayerId))
                continue;

            server.Events.ObjectSpawned(
                connection,
                obj.PrefabId,
                obj.NetworkId,
                obj.OwnerPlayerId,
                obj.IsPlayer,
                obj.Position.X,
                obj.Position.Y,
                obj.Position.Z,
                obj.Rotation.X,
                obj.Rotation.Y,
                obj.Rotation.Z,
                obj.Rotation.W);

            server.Events.ObjectTransform(
                connection,
                obj.NetworkId,
                obj.Position.X,
                obj.Position.Y,
                obj.Position.Z,
                obj.Rotation.X,
                obj.Rotation.Y,
                obj.Rotation.Z,
                obj.Rotation.W,
                obj.Velocity.X,
                obj.Velocity.Y,
                obj.Velocity.Z,
                obj.AngularVelocity.X,
                obj.AngularVelocity.Y,
                obj.AngularVelocity.Z);

            SendChildTransformStateTo(server, obj, connection);

            foreach (KeyValuePair<uint, object> value in obj.Values)
            {
                if (!obj.Variables.TryGetValue(value.Key, out NetworkVariableState? variable))
                    continue;

                ushort behaviourId = (ushort)(value.Key >> 16);
                ushort variableId = (ushort)value.Key;

                server.Events.NetworkVariable(
                    connection,
                    obj.NetworkId,
                    variableId,
                    variable.Type,
                    value.Value,
                    behaviourId);
            }

            SendNetworkCollectionStateTo(server, obj, connection);
        }

        foreach (NetworkObjectState obj in server.World.Objects)
        {
            if (obj.Room != room || !string.Equals(obj.AppId, connection.AppId, StringComparison.OrdinalIgnoreCase))
                continue;

            if (!IsObjectVisibleTo(obj, connection.Player.PlayerId))
                continue;

            ReplayBufferedRpcs(server, obj, connection);
        }
    }

    private void HandleSuccessfulRoomJoin(RelayServer server, RelayConnection connection)
    {
        Room? room = connection.Room;

        if (room == null)
            return;

        connection.SceneReady = string.IsNullOrEmpty(room.CurrentScene);

        server.Events.RoomJoined(connection, room);

        foreach (RelayPlayer player in room.ActivePlayers)
        {
            server.Events.PlayerSync(connection, player);
        }
        PropertyChanges roomProperties = new();

        foreach (var property in room.Properties)
        {
            roomProperties[property.Key] = property.Value;
        }

        server.Events.RoomProperties(connection, room, roomProperties);

        foreach (RelayPlayer player in room.ActivePlayers)
        {
            if (player == connection.Player)
                continue;

            RelayConnection? other = server.GetConnection(room, player);

            if (other == null)
                continue;

            server.Events.PlayerJoined(other, connection.Player!);
        }

        SpawnPlayer(server, connection);
    }

    private void SpawnPlayer(RelayServer server, RelayConnection connection)
    {
        if (connection.Room == null || connection.Player == null)
            return;

        if (connection.Player.PlayerObjectId != 0)
        {
            Console.WriteLine($"Player {connection.Player.Username} already has a player object.");
            return;
        }

        uint networkId = server.AllocateNetworkId();

        NetworkObjectState playerObject = new()
        {
            NetworkId = networkId,
            PrefabId = 0,
            OwnerPlayerId = connection.Player.PlayerId,
            LeaderCanControl = false,
            KeepAfterOwnerLeaves = false,
            IsPlayer = true,
            Room = connection.Room,
            AppId = connection.AppId,
            Position = Vector3.Zero,
            Rotation = Quaternion.Identity,
            ChildTransformCount = connection.PlayerChildTransformCount
        };

        AllocateChildTransforms(playerObject);

        if (!server.World.Add(playerObject))
        {
            Console.WriteLine($"[Server] Failed to register player object {playerObject.NetworkId}");
            return;
        }

        connection.Player.PlayerObjectId = networkId;

        foreach (RelayPlayer player in connection.Room.ActivePlayers)
        {
            RelayConnection target = server.GetConnection(connection.Room, player);

            if (target == null)
                continue;

            server.Events.ObjectSpawned(
                target,
                playerObject.PrefabId,
                playerObject.NetworkId,
                playerObject.OwnerPlayerId,
                playerObject.IsPlayer,
                playerObject.Position.X,
                playerObject.Position.Y,
                playerObject.Position.Z,
                playerObject.Rotation.X,
                playerObject.Rotation.Y,
                playerObject.Rotation.Z,
                playerObject.Rotation.W);
        }

        foreach (NetworkObjectState obj in server.World.Objects)
        {
            if (obj.Room != connection.Room)
                continue;

            if (obj.NetworkId == playerObject.NetworkId)
                continue;

            if (!IsObjectVisibleTo(obj, connection.Player.PlayerId))
                continue;

            server.Events.ObjectSpawned(connection, obj.PrefabId, obj.NetworkId, obj.OwnerPlayerId, obj.IsPlayer, obj.Position.X, obj.Position.Y, obj.Position.Z, obj.Rotation.X, obj.Rotation.Y, obj.Rotation.Z, obj.Rotation.W);

            SendChildTransformStateTo(server, obj, connection);
            SendNetworkCollectionStateTo(server, obj, connection);
        }

        foreach (NetworkObjectState obj in server.World.Objects)
        {
            if (obj.Room != connection.Room)
                continue;

            if (!IsObjectVisibleTo(obj, connection.Player.PlayerId))
                continue;

            ReplayBufferedRpcs(server, obj, connection);
        }
    }
}