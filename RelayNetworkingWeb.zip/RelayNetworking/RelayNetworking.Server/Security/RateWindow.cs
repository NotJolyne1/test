﻿namespace RelayNetworking.Server.Security;

internal sealed class RateWindow
{
    private readonly int _limit;
    private readonly TimeSpan _window;
    private int _count;
    private DateTime _windowStart;

    public RateWindow(int limit, TimeSpan window)
    {
        _limit = limit;
        _window = window;
        _windowStart = DateTime.UtcNow;
    }

    public bool TryConsume(int amount = 1)
    {
        DateTime now = DateTime.UtcNow;

        if (now - _windowStart >= _window)
        {
            _windowStart = now;
            _count = 0;
        }

        if (_count + amount > _limit)
            return false;

        _count += amount;

        return true;
    }
}
