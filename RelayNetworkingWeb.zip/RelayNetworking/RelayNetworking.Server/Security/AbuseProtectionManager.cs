﻿using RelayNetworking.Server.Applications;
using RelayNetworking.Server.Transport;

namespace RelayNetworking.Server.Security;

internal sealed class AbuseProtectionManager
{
    private const string UnregisteredAppKey = "\u0000unregistered";

    private readonly RelayServerOptions _options;
    private readonly ApplicationManager _applications;

    private readonly Dictionary<string, IpState> _ipStates = new();
    private readonly Dictionary<string, AppState> _appStates = new(StringComparer.OrdinalIgnoreCase);
    private readonly Dictionary<string, IpAppState> _ipAppStates = new();

    private DateTime _lastCleanup = DateTime.UtcNow;

    public AbuseProtectionManager(RelayServerOptions options, ApplicationManager applications)
    {
        _options = options;
        _applications = applications;
    }

    private IpState GetIp(string ip)
    {
        if (!_ipStates.TryGetValue(ip, out IpState? state))
        {
            state = new IpState(_options);
            _ipStates[ip] = state;
        }

        state.LastSeen = DateTime.UtcNow;
        return state;
    }

    private string NormalizeAppId(string appId)
    {
        if (!_applications.IsRegistered(appId))
            return UnregisteredAppKey;

        return appId;
    }

    private AppState GetApp(string appId)
    {
        string key = NormalizeAppId(appId);

        if (!_appStates.TryGetValue(key, out AppState? state))
        {
            state = new AppState(_options, key == UnregisteredAppKey);
            _appStates[key] = state;
        }

        state.LastSeen = DateTime.UtcNow;
        return state;
    }

    private IpAppState GetIpApp(string ip, string appId)
    {
        string key = ip + "|" + NormalizeAppId(appId);

        if (!_ipAppStates.TryGetValue(key, out IpAppState? state))
        {
            state = new IpAppState(_options);
            _ipAppStates[key] = state;
        }

        state.LastSeen = DateTime.UtcNow;
        return state;
    }

    public bool IsCoolingDown(string ip)
    {
        IpState state = GetIp(ip);
        return state.CooldownUntil.HasValue && DateTime.UtcNow < state.CooldownUntil.Value;
    }

    public bool TryConsumeConnectionAttempt(string ip)
    {
        return GetIp(ip).ConnectionAttempts.TryConsume();
    }

    public bool TryConsumeAuthAttempt(string ip)
    {
        return GetIp(ip).AuthAttempts.TryConsume();
    }

    public void RecordFailedAuth(string ip)
    {
        if (!GetIp(ip).FailedAuthAttempts.TryConsume())
            RegisterViolation(ip, "failed authentication rate exceeded");
    }

    public bool TryConsumeRoomCreation(string ip, string appId)
    {
        IpState ipState = GetIp(ip);
        AppState appState = GetApp(appId);
        IpAppState ipAppState = GetIpApp(ip, appId);

        if (!ipState.RoomCreations.TryConsume())
            return false;

        if (!appState.RoomCreations.TryConsume())
            return false;

        if (!ipAppState.RoomCreations.TryConsume())
            return false;

        return true;
    }

    public bool TryConsumeRoomJoin(string ip, string appId)
    {
        IpState ipState = GetIp(ip);
        IpAppState ipAppState = GetIpApp(ip, appId);

        if (!ipState.RoomJoins.TryConsume())
            return false;

        if (!ipAppState.RoomJoins.TryConsume())
            return false;

        return true;
    }

    public void RegisterViolation(string ip, string reason)
    {
        IpState state = GetIp(ip);

        state.AbuseScore++;

        Console.WriteLine($"[Security] {reason} for {ip} (score {state.AbuseScore}/{_options.AbuseViolationsBeforeCooldown})");

        if (state.AbuseScore < _options.AbuseViolationsBeforeCooldown)
            return;

        state.CooldownUntil = DateTime.UtcNow + _options.AbuseCooldown;
        state.AbuseScore = 0;

        Console.WriteLine($"[Security] Temporary cooldown applied to {ip} for {(int)_options.AbuseCooldown.TotalSeconds}s");
    }

    public void Cleanup(DateTime now)
    {
        if (now - _lastCleanup < _options.AbuseStateCleanupInterval)
            return;

        _lastCleanup = now;

        List<string> stale = new();

        foreach (var pair in _ipStates)
        {
            bool cooling = pair.Value.CooldownUntil.HasValue && now < pair.Value.CooldownUntil.Value;

            if (!cooling && now - pair.Value.LastSeen > _options.AbuseStateMaxIdle)
                stale.Add(pair.Key);
        }

        foreach (string key in stale)
            _ipStates.Remove(key);

        stale.Clear();

        foreach (var pair in _appStates)
        {
            if (now - pair.Value.LastSeen > _options.AbuseStateMaxIdle)
                stale.Add(pair.Key);
        }

        foreach (string key in stale)
            _appStates.Remove(key);

        stale.Clear();

        foreach (var pair in _ipAppStates)
        {
            if (now - pair.Value.LastSeen > _options.AbuseStateMaxIdle)
                stale.Add(pair.Key);
        }

        foreach (string key in stale)
            _ipAppStates.Remove(key);
    }

    private sealed class IpState
    {
        public IpState(RelayServerOptions options)
        {
            ConnectionAttempts = new RateWindow(options.MaxConnectionAttemptsPerIpPerMinute, TimeSpan.FromMinutes(1));
            AuthAttempts = new RateWindow(options.MaxAuthenticationAttemptsPerIpPerMinute, TimeSpan.FromMinutes(1));
            FailedAuthAttempts = new RateWindow(options.MaxFailedAuthenticationAttemptsPerIpPerMinute, TimeSpan.FromMinutes(1));
            RoomCreations = new RateWindow(options.MaxRoomCreationsPerIpPerMinute, TimeSpan.FromMinutes(1));
            RoomJoins = new RateWindow(options.MaxRoomJoinsPerIpPerMinute, TimeSpan.FromMinutes(1));
        }

        public RateWindow ConnectionAttempts { get; }
        public RateWindow AuthAttempts { get; }
        public RateWindow FailedAuthAttempts { get; }
        public RateWindow RoomCreations { get; }
        public RateWindow RoomJoins { get; }

        public int AbuseScore;
        public DateTime? CooldownUntil;
        public DateTime LastSeen = DateTime.UtcNow;
    }

    private sealed class AppState
    {
        public AppState(RelayServerOptions options, bool shared)
        {
            int limit = shared ? Math.Min(options.MaxRoomCreationsPerAppPerMinute, options.MaxRoomCreationsPerIpPerMinute) : options.MaxRoomCreationsPerAppPerMinute;
            RoomCreations = new RateWindow(limit, TimeSpan.FromMinutes(1));
        }

        public RateWindow RoomCreations { get; }
        public DateTime LastSeen = DateTime.UtcNow;
    }

    private sealed class IpAppState
    {
        public IpAppState(RelayServerOptions options)
        {
            RoomCreations = new RateWindow(options.MaxRoomCreationsPerIpPerAppPerMinute, TimeSpan.FromMinutes(1));
            RoomJoins = new RateWindow(options.MaxRoomJoinsPerIpPerAppPerMinute, TimeSpan.FromMinutes(1));
        }

        public RateWindow RoomCreations { get; }
        public RateWindow RoomJoins { get; }
        public DateTime LastSeen = DateTime.UtcNow;
    }
}