﻿using RelayNetworking.Server.Rooms;

internal sealed class RelayApplication
{
    public RelayApplication(string appId)
    {
        AppId = appId;
    }

    public string AppId { get; }

    public AuthenticationType AuthenticationType { get; set; } = AuthenticationType.None;
}