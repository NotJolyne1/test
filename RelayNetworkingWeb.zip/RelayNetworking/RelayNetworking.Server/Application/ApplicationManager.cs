﻿namespace RelayNetworking.Server.Applications;

internal sealed class ApplicationManager
{
    private readonly Dictionary<string, RelayApplication> _applications = new(StringComparer.OrdinalIgnoreCase);
    private readonly HashSet<string> _registered = new(StringComparer.OrdinalIgnoreCase);

    public RelayApplication GetOrCreate(string appId)
    {
        if (_applications.TryGetValue(appId, out RelayApplication? application))
            return application;

        application = new RelayApplication(appId);

        _applications.Add(appId, application);

        return application;
    }

    public bool TryGetApplication(string appId, out RelayApplication application)
    {
        return _applications.TryGetValue(appId, out application!);
    }

    public void Register(string appId)
    {
        _registered.Add(appId);
        GetOrCreate(appId);
    }

    public bool IsRegistered(string appId)
    {
        return !string.IsNullOrEmpty(appId) && _registered.Contains(appId);
    }
}