﻿using System.Diagnostics;

namespace RelayNetworking.Server.Time;

public sealed class ServerClock
{
    private readonly object _lock = new();
    private readonly Stopwatch _stopwatch;
    private double _accumulator;
    private double _lastElapsedSeconds;
    private const double MaxAccumulatorSeconds = 1.0;

    public ServerClock(int tickRate)
    {
        if (tickRate <= 0)
            throw new ArgumentOutOfRangeException(nameof(tickRate), "Tick rate must be greater than zero.");

        TickRate = tickRate;
        TickDuration = 1.0 / tickRate;

        _stopwatch = Stopwatch.StartNew();
        _lastElapsedSeconds = _stopwatch.Elapsed.TotalSeconds;
    }

    public int TickRate { get; }

    public double TickDuration { get; }

    public double ServerTime
    {
        get
        {
            lock (_lock)
                return _serverTime;
        }
    }
    private double _serverTime;

    public ulong CurrentTick
    {
        get
        {
            lock (_lock)
                return _currentTick;
        }
    }
    private ulong _currentTick;

    public int Advance(Action<ulong>? onTick = null)
    {
        double nowElapsed = _stopwatch.Elapsed.TotalSeconds;

        int ticksRun = 0;

        lock (_lock)
        {
            double delta = nowElapsed - _lastElapsedSeconds;
            _lastElapsedSeconds = nowElapsed;

            if (delta < 0)
                delta = 0;

            _accumulator += delta;

            if (_accumulator > MaxAccumulatorSeconds)
                _accumulator = MaxAccumulatorSeconds;

            while (_accumulator >= TickDuration)
            {
                _accumulator -= TickDuration;

                _currentTick++;
                _serverTime += TickDuration;

                ticksRun++;

                onTick?.Invoke(_currentTick);
            }
        }

        return ticksRun;
    }
}
