Browser players (Racing Thing web version)
WebRelay.cs starts a browser port (8080) by itself when the server starts.
index.html (in the RelayNetworking.Server folder) is the game page.
Everyone opens http://<this computer's address>:8080 in a browser.
If "[Web] Browser players" does not print, add after server.Start():
    RelayNetworking.Server.Web.WebRelay.Start(8080);
