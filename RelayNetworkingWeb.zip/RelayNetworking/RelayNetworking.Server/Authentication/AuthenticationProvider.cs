﻿using RelayNetworking.Common.Authentication;
using RelayNetworking.Server.Transport;

namespace RelayNetworking.Server.Authentication;

public abstract class AuthenticationProvider : IAuthenticationProvider
{
    protected RelayServerOptions Options { get; }

    protected AuthenticationProvider(RelayServerOptions options)
    {
        Options = options;
    }

    public virtual bool IsPersistent => false;

    public abstract Task<AuthenticationResult> AuthenticateAsync(AuthenticationRequest request);
}