﻿using RelayNetworking.Common.Authentication;

namespace RelayNetworking.Server.Authentication.Services;

public interface IAuthenticationValidator
{
    Task<AuthenticationResult> ValidateAsync(AuthenticationRequest request);
}