﻿using RelayNetworking.Common.Authentication;

namespace RelayNetworking.Server.Authentication.Services;

internal sealed class AuthenticationValidator : IAuthenticationValidator
{
    public Task<AuthenticationResult> ValidateAsync(AuthenticationRequest request)
    {
        return Task.FromResult(new AuthenticationResult
        {
            Success = false,
            ErrorMessage = "No validator configured."
        });
    }
}