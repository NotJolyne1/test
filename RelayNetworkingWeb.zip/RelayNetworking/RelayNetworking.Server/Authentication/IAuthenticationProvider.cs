﻿using RelayNetworking.Common.Authentication;

namespace RelayNetworking.Server.Authentication;

public interface IAuthenticationProvider
{
    bool IsPersistent { get; }

    Task<AuthenticationResult> AuthenticateAsync(AuthenticationRequest request);
}