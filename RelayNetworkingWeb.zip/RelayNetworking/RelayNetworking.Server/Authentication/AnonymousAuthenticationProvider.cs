﻿using RelayNetworking.Common.Authentication;
using RelayNetworking.Server.Transport;

namespace RelayNetworking.Server.Authentication;

internal sealed class AnonymousAuthenticationProvider : AuthenticationProvider
{
    public AnonymousAuthenticationProvider(RelayServerOptions options) : base(options) { }
    public override bool IsPersistent => false;

    public override Task<AuthenticationResult> AuthenticateAsync(AuthenticationRequest request)
    {
        return Task.FromResult(new AuthenticationResult
        {
            Success = true,
            UserId = Guid.NewGuid().ToString(),
            Username = request.Username
        });
    }
}